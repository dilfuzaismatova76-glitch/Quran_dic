
'use strict';
const $ = s => document.querySelector(s);
const U = c => String.fromCharCode(parseInt(c, 16));
// Buckwalter -> Arabic
const B2A = {"'":"ء","|":"آ",">":"أ","&":"ؤ","<":"إ","}":"ئ",A:"ا",b:"ب",p:"ة",t:"ت",v:"ث",j:"ج",H:"ح",x:"خ",d:"د","*":"ذ",r:"ر",z:"ز",s:"س",$:"ش",S:"ص",D:"ض",T:"ط",Z:"ظ",E:"ع",g:"غ",_:"ـ",f:"ف",q:"ق",k:"ك",l:"ل",m:"م",n:"ن",h:"ه",w:"و",Y:"ى",y:"ي",
  F:U('64B'),N:U('64C'),K:U('64D'),a:U('64E'),u:U('64F'),i:U('650'),"~":U('651'),o:U('652'),"^":U('653'),"#":U('654'),"`":U('670'),
  "{":"ٱ",":":U('6DC'),"@":U('6DF'),'"':U('6E0'),"[":U('6E2'),";":U('6E3'),",":U('6E5'),".":U('6E6'),M:U('6ED'),"]":U('6ED'),"-":U('6EA'),"+":U('6EB'),"%":U('6EC'),"!":U('6E8')};
const A2B = {};
for (const k in B2A) A2B[B2A[k]] = k;
Object.assign(A2B, {"ة":"h","ى":"y","ئ":"A","ؤ":"A","أ":"A","إ":"A","آ":"AA","ء":"A","ٱ":"A"});
// ءَا (хамза + фатха + алиф) пишем как آ
const ar = t => t.replace(/[\s\S]/g, c => B2A[c] || c).replace(/\u0621\u064E\u0627\u0653?/g, '\u0622');
const rootAr = r => [...r].map(c => c === 'A' ? 'أ' : (B2A[c] || c)).join(' ');
const toBW = t => t.replace(/[\s\S]/g, c => A2B[c] || c);
const skel = t => t.replace(/[aiuoFNK~`^#:@"\[\];,.M_\-+%!]/g, '').replace(/\|/g, 'AA').replace(/[<>&}'{]/g, 'A').replace(/Y/g, 'y');
const esc = t => String(t).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt = n => n.toLocaleString('ru-RU');

const ORD = "AbtvjHxd*rzs$SDTZEgfqklmnhwy";
const RK = {}; [...ORD].forEach((c, i) => RK[c] = i);
const TN = {N:'Noun',PN:'Proper noun',V:'Verb',ADJ:'Adjective',P:'Preposition',PRON:'Pronoun',DEM:'Demonstrative pronoun',REL:'Relative pronoun',T:'Time adverb',LOC:'Location adverb',CONJ:'Conjunction',DET:'Determiner',NEG:'Negative particle',ACC:'Accusative particle',EMPH:'Emphatic particle',INTG:'Interrogative particle',COND:'Conditional particle',SUB:'Subordinating conjunction',REM:'Resumption particle',VOC:'Vocative particle',CERT:'Certainty particle',RSLT:'Result particle',PRO:'Prohibition particle',PRP:'Purpose particle',CIRC:'Circumstantial particle',SUP:'Supplemental particle',PREV:'Preventive particle',FUT:'Future particle',RET:'Retraction particle',RES:'Restriction particle'};
const TORD = ['PN','N','V','ADJ','P','PRON','DEM','REL','T','LOC'];
const FD = {STEM:'Stem',PREFIX:'Prefix',SUFFIX:'Suffix',M:'Masculine',F:'Feminine',MS:'Masculine singular',FS:'Feminine singular',MP:'Masculine plural',FP:'Feminine plural',MD:'Masculine dual',FD:'Feminine dual',GEN:'Genitive',NOM:'Nominative',ACC:'Accusative',PERF:'Perfect',IMPF:'Imperfect',IMPV:'Imperative',INDEF:'Indefinite',ACT:'Active',PASS:'Passive',PCPL:'Participle',VN:'Verbal noun',SP:'Special group',MOOD:'Mood',PRON:'Pronoun',INDIC:'Indicative'};

let recs = [], aIdx = new Map(), byRoot = new Map(), byLemma = new Map(), rootList = [];
const state = {letter:'', q:'', root:null, form:'', lem:'', limit:100, dm:'roots', vs:1, thr:15};

// ---------- Qvocab: русские переводы слов и значения корней ----------
const QW = new Map(), RM = JSON.parse(DATA['qv-roots']), QG = JSON.parse(DATA['qv-gram']);
function buildQW(text) {
  for (const ln of text.split('\n')) {
    if (!ln) continue; const p = ln.split('\t'), c = p[0].split(':');
    QW.set((+c[0] * 1000 + +c[1]) * 1000 + +c[2], [p[1], +p[2]]);
  }
}
const qwOf = r => QW.get((r.s * 1000 + r.a) * 1000 + r.w);
const gramRu = i => (QG[i] || '').split('|').filter(Boolean).join(' · ');
const qvCell = r => { const q = qwOf(r); return q ? `${esc(q[0])}<div class="feat">${esc(gramRu(q[1]))}</div>` : '<span class="feat">—</span>'; };

// ---------- Переводы аятов: Абу Адель (RU) и Мухаммад Содик (UZ, кириллица, сноски в тексте) ----------
let TR = null;
const trPrefs = (() => { try { return Object.assign({ru: true, uz: true, fn: true, ruo: false, mso: false}, JSON.parse(localStorage.getItem('qd-tr'))); } catch (e) { return {ru: true, uz: true, fn: true, ruo: false, mso: false}; } })();
function applyTrPrefs() {
  for (const k of ['ru', 'uz', 'fn']) document.body.classList.toggle('no-' + k, !trPrefs[k]);
  document.querySelectorAll('#tbar button').forEach(b => b.setAttribute('aria-pressed', String(trPrefs[b.dataset.tr])));
}
const trFmt = t => esc(t).replace(/\[\[([\s\S]*?)\]\]/g, (m, x) => '<span class="fn">[' + x + ']</span>');
const trHTML = (s, a) => TR ? ['uz', 'ru'].map(k => `<div class="tr tr-${k}"><b>${k.toUpperCase()}</b>${trFmt(TR[k][s + ':' + a] || '')}</div>`).join('') : '';
const trPlain = (s, a, k) => TR ? (TR[k][s + ':' + a] || '').replace(/\[\[[\s\S]*?\]\]/g, '').trim() : '';
async function loadTr() {
  await window.loadScript('data/tr.js');
  const bin = Uint8Array.from(atob(window.TR_B64), c => c.charCodeAt(0)); window.TR_B64 = null;
  const txt = await new Response(new Blob([bin]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
  TR = JSON.parse(txt); rowCache.clear(); if (recs.length) render(); if (typeof applySel === 'function') applySel();
}

// ---------- parsing (chunked, non-blocking) ----------
let awCache = new Map(), rowCache = new Map();
function parseText(text, name) {
  const lines = text.split('\n');
  ingest(lines.length, i => {
    let ln = lines[i];
    if (!ln || ln[0] !== '(') return null;
    if (ln.charCodeAt(ln.length - 1) === 13) ln = ln.slice(0, -1);
    const p = ln.split('\t');
    if (p.length < 4) return null;
    const c = p[0].slice(1, -1).split(':');
    return [+c[0], +c[1], +c[2], +c[3], p[1], p[2], p[3]];
  }, name, false);
}
// getRow(i) -> [surah, ayah, word, segment, form, tag, features] | null
function ingest(n, getRow, name, save) {
  recs = []; aIdx = new Map(); byRoot = new Map(); byLemma = new Map(); awCache = new Map(); rowCache = new Map();
  let i = 0; const t0 = performance.now();
  function step() {
    const end = Math.min(i + 20000, n);
    for (; i < end; i++) {
      const row = getRow(i);
      if (!row) continue;
      const fs = row[6];
      const r = {s:row[0], a:row[1], w:row[2], g:row[3], form:row[4], tag:row[5], feat:fs, root:'', lem:'', i:recs.length};
      let k = fs.indexOf('|ROOT:');
      if (k >= 0) { const e = fs.indexOf('|', k + 6); r.root = fs.slice(k + 6, e < 0 ? undefined : e); }
      k = fs.indexOf('|LEM:');
      if (k >= 0) { const e = fs.indexOf('|', k + 5); r.lem = fs.slice(k + 5, e < 0 ? undefined : e); }
      recs.push(r);
      const key = r.s * 1000 + r.a;
      (aIdx.get(key) || aIdx.set(key, []).get(key)).push(r);
      if (r.root) (byRoot.get(r.root) || byRoot.set(r.root, {root:r.root, recs:[], forms:new Set(), lemmas:new Set()}).get(r.root)).recs.push(r);
      if (r.lem) (byLemma.get(r.lem) || byLemma.set(r.lem, []).get(r.lem)).push(r);
    }
    $('#status').textContent = 'Разбор: ' + Math.round(i / n * 100) + '%';
    if (i < n) setTimeout(step, 0); else finish(name, t0, save);
  }
  step();
}
function finish(name, t0, save) {
  for (const o of byRoot.values()) {
    o.n = o.recs.length;
    for (const r of o.recs) { o.forms.add(r.form); o.lemmas.add(r.lem); }
    o.sk = skel(o.root);
    o.hay = o.sk + ' ' + [...o.lemmas].map(skel).join(' ') + ' ' + [...o.forms].map(skel).join(' ');
    o.mean = RM[o.root] || ''; const tr = new Set(); for (const r of o.recs) { const q = qwOf(r); if (q) tr.add(q[0].toLowerCase()); } o.ru = (o.mean + ' ; ' + [...tr].join(' ; ')).toLowerCase();
  }
  rootList = [...byRoot.values()].sort((a, b) => {
    for (let i = 0; i < Math.min(a.root.length, b.root.length); i++) {
      const d = (RK[a.root[i]] ?? 99) - (RK[b.root[i]] ?? 99);
      if (d) return d;
    }
    return a.root.length - b.root.length;
  });
  $('#status').textContent = `${name}: ${fmt(recs.length)} сегментов, ${fmt(rootList.length)} корней, ${Math.round(performance.now() - t0)} мс`;
  $('#q').disabled = false;
  corpusReady = true; setLoadBar(1, 1); buildLetters(); render(); onCorpusReady();
}

// ---------- UI ----------
// ---------- Поэтапная загрузка: список корней сразу, корпус по сурам догружается в фоне ----------
let corpusReady = false;
function setLoadBar(done, total, text) {
  let b = document.getElementById('loadbar');
  if (done >= total) { if (b) b.remove(); return; }
  if (!b) { b = document.createElement('div'); b.id = 'loadbar'; b.innerHTML = '<span></span><i></i>'; document.body.appendChild(b); }
  b.firstChild.textContent = text + ' ' + done + '/' + total; b.lastChild.style.width = Math.round(done / total * 100) + '%';
}
function waitMsg() {
  $('#view').innerHTML = '<p class="empty">Корпус ещё загружается — страница откроется сама, как только данные будут готовы.</p>';
  $('#count').textContent = ''; $('#csv').disabled = true;
}
function earlyRoots() {
  const idx = JSON.parse(DATA['roots-index']); delete DATA['roots-index'];
  rootList = idx.map(([root, n]) => { const mean = RM[root] || ''; return {root, n, mean, sk: skel(root), hay: skel(root), ru: mean.toLowerCase(), forms: new Set(), lemmas: new Set(), recs: null}; });
  $('#q').disabled = false; buildLetters(); render();
}
async function loadRest() {
  const nums = Array.from({length: 114}, (_, i) => i + 1), total = nums.length + 2;
  let done = 0; const tick = t => setLoadBar(Math.min(++done, total - 1), total, t);
  setLoadBar(0, total, 'Загрузка корпуса');
  const queue = nums.slice();
  await Promise.all(Array.from({length: 6}, async () => {
    let s; while ((s = queue.shift())) { await window.loadScript('data/corpus/' + String(s).padStart(3, '0') + '.js'); tick('Загрузка корпуса'); }
  }));
  await window.loadScript('data/qv-words.js'); buildQW(DATA['qv-words']); delete DATA['qv-words']; tick('Загрузка переводов слов');
  await Promise.all([window.loadScript('data/mushaf-marks.js'), window.loadScript('data/mushaf-pages.js')]);
  MK = JSON.parse(DATA['mushaf-marks']); MP = JSON.parse(DATA['mushaf-pages']); tick('Загрузка Мусхафа');
  const text = nums.map(s => DATA['c' + s]).join('');
  window.DATA = null;
  parseText(text, 'embedded');
  applyTrPrefs();
  loadTr().catch(e => console.warn('Переводы аятов недоступны:', e));
}
function startStages() {
  earlyRoots();
  loadRest().catch(e => { const b = document.getElementById('loadbar'); if (b) b.firstChild.textContent = 'Не удалось загрузить данные (' + e.message + '). Проверьте соединение и обновите страницу.'; });
}

function buildLetters() {
  $('#letters').innerHTML = `<button data-l="" aria-pressed="false" style="font:inherit;font-size:1rem">Все</button>` +
    [...ORD].map(c => `<button data-l="${esc(c)}" aria-pressed="false">${c === 'A' ? 'ا' : B2A[c]}</button>`).join('');
}
function search(q) {
  const t = q.trim();
  if (/[а-яё]/i.test(t)) { const w = t.toLowerCase(), sc = o => o.mean.toLowerCase().includes(w) ? 0 : 1; return rootList.filter(o => o.ru.includes(w)).sort((a, b) => sc(a) - sc(b)); }
  const k = skel(toBW(t)).replace(/\s+/g, '');
  if (!k) return rootList;
  const sc = o => o.sk.startsWith(k) ? 0 : o.sk.includes(k) ? 1 : 2;
  return rootList.filter(o => o.hay.includes(k)).sort((a, b) => sc(a) - sc(b));
}
function render() {
  document.querySelectorAll('#dmode button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.dm === state.dm)));
  if (!corpusReady && (state.dm === 'sura' || state.root || state.lem)) return waitMsg();
  const rm = state.dm === 'roots'; $('#letters').hidden = !rm; $('#qbar').hidden = !rm;
  if (!rm) { $('#h1root').textContent = ''; $('#crumbs').innerHTML = '<a data-dm="roots">Словарь</a>'; $('#csv').disabled = true; return state.dm === 'freq' ? renderFreq() : renderSura(); }
  document.querySelectorAll('#letters button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.l === state.letter)));
  const o = state.root && byRoot.get(state.root);
  $('#h1root').textContent = state.lem ? ' — ' + ar(state.lem) : o ? ' — ' + rootAr(o.root) : '';
  let cr = `<a data-c="all">Словарь</a>`;
  if (state.letter) cr += ` → <a data-c="letter"><span class="ar">${state.letter === 'A' ? 'ا' : B2A[state.letter]}</span></a>`;
  if (o) cr += state.lem ? ` → <a data-root="${esc(o.root)}"><span class="ar">${rootAr(o.root)}</span></a>` : ` → <span class="ar">${rootAr(o.root)}</span>`;
  if (state.lem) cr += ` → <span class="ar">${ar(state.lem)}</span>`;
  $('#crumbs').innerHTML = cr;
  $('#csv').disabled = !o;
  state.lem && byLemma.has(state.lem) ? renderLemma() : o ? renderRoot(o) : renderList();
}
function renderList() {
  let list = state.q.trim() ? search(state.q) : state.letter ? rootList.filter(o => o.root[0] === state.letter) : rootList;
  const cut = list.slice(0, 400);
  $('#view').innerHTML = `<p>Корней: <b>${fmt(list.length)}</b></p><div class="chips">` +
    cut.map(o => `<button class="chip" data-root="${esc(o.root)}"><span class="ar">${rootAr(o.root)}</span><small>${o.n}${o.n === 1 ? ' · hapax' : ''}</small>${o.mean ? `<em class="rmn">${esc(o.mean)}</em>` : ''}</button>`).join('') +
    `</div>` + (list.length > cut.length ? `<p class="empty">Показаны первые 400. Уточните поиск или выберите букву.</p>` : '') +
    (list.length ? '' : `<p class="empty">Ничего не найдено. Попробуйте другую запись корня.</p>`);
  $('#count').textContent = `Корней: ${fmt(list.length)}`;
}
// новое слово = новый номер word; сегменты одного слова склеиваются без пробела
function ayahWords(s, a) {
  const key = s * 1000 + a;
  let out = awCache.get(key);
  if (out) return out;
  const m = new Map();
  for (const r of aIdx.get(key) || []) m.set(r.w, (m.get(r.w) || '') + r.form);
  out = [...m].sort((x, y) => x[0] - y[0]).map(([w, b]) => ({w, t: ar(b)}));
  awCache.set(key, out);
  return out;
}
function ayahHTML(r) {
  return ayahWords(r.s, r.a).map(x => {
    const at = `class="w" data-s="${r.s}" data-a="${r.a}" data-w="${x.w}"`;
    return x.w === r.w ? `<mark ${at}>${x.t}</mark>` : `<span ${at}>${x.t}</span>`;
  }).join(' ');
}
const loc = r => `(${r.s}:${r.a}:${r.w})`;
const featSum = r => r.feat.split('|').filter(t => !/^(STEM|POS:|LEM:|ROOT:)/.test(t)).map(t => t.startsWith('SP:') ? 'SP:' + ar(t.slice(3)) : t).join(' ');
function rowHTML(r) {
  let h = rowCache.get(r.i);
  if (!h) rowCache.set(r.i, h = `<tr><td><button class="loc" data-m="${r.i}" title="Показать в мусхафе">${loc(r)}</button></td>
      <td><span class="ar">${ar(r.form)}</span> <button class="info" data-i="${r.i}" title="Разбор слова" aria-label="Разбор слова">ⓘ</button></td>
      <td>${qvCell(r)}</td>
      <td>${r.lem ? `<a class="ar lk" data-lem="${esc(r.lem)}" title="Всё о лемме">${ar(r.lem)}</a>` : ''}<div class="feat">${esc(featSum(r))}</div></td>
      <td class="a"><span class="ar">${ayahHTML(r)}</span>${trHTML(r.s, r.a)}</td></tr>`);
  return h;
}
function currentEntries(o) { const base = state.lem ? (byLemma.get(state.lem) || []) : o.recs; return state.form ? base.filter(r => r.form === state.form) : base; }
function renderRoot(o) {
  const es = currentEntries(o);
  const groups = new Map();
  for (const r of es) (groups.get(r.tag) || groups.set(r.tag, []).get(r.tag)).push(r);
  const tags = [...groups.keys()].sort((x, y) => {
    const i = TORD.indexOf(x), j = TORD.indexOf(y);
    return (i < 0 ? 99 : i) - (j < 0 ? 99 : j) || x.localeCompare(y);
  });
  let shown = 0, html = '';
  for (const t of tags) {
    if (shown >= state.limit) break;
    const rows = groups.get(t).slice(0, state.limit - shown); shown += rows.length;
    html += `<h3>${TN[t] || t} <small>(${t}) — ${groups.get(t).length}</small></h3><div class="tw"><table><thead><tr><th>Location</th><th>Form</th><th>Перевод</th><th>Lemma / признаки</th><th>Аят</th></tr></thead><tbody>` +
      rows.map(rowHTML).join('') + `</tbody></table></div>`;
  }
  const hapax = o.n === 1 ? '<span class="badge">hapax</span>' : '';
  $('#view').innerHTML = `<div class="sum"><a class="ar lk" data-c="allforms" title="Показать все формы корня" style="font-size:1.8rem;color:var(--acc)">${rootAr(o.root)}</a> — ${o.n} раз${hapax}<br>
    Корень встречается ${o.n} раз, ${o.forms.size} производных форм, ${o.lemmas.size} лемм.${o.mean ? `<br>Значение: <b>${esc(o.mean)}</b>` : ''}
    ${state.form ? `<br>Фильтр по форме: <b class="ar">${ar(state.form)}</b> <button data-c="clearform">✕ все формы корня</button>` : ''}</div>` + chipsHTML(o.recs) + html +
    (shown < es.length ? `<p><button data-c="more">Показать ещё ${Math.min(100, es.length - shown)} (осталось ${es.length - shown})</button></p>` : '');
  $('#count').textContent = `Показано ${fmt(shown)} из ${fmt(es.length)} вхождений`;
}
function chipsHTML(list) {
  const fc = new Map(), lc = new Map();
  for (const r of list) { fc.set(r.form, (fc.get(r.form) || 0) + 1); if (r.lem) lc.set(r.lem, (lc.get(r.lem) || 0) + 1); }
  const fb = [...fc].sort((a, b) => b[1] - a[1]).map(([f, n]) => `<button class="chip" data-form="${esc(f)}" aria-pressed="${state.form === f}"><span class="ar">${ar(f)}</span><small>${n}</small></button>`).join('');
  let h = `<details class="fl" open><summary>Формы (${fc.size}) — нажмите, чтобы отфильтровать</summary><div class="chips">${fb}</div></details>`;
  if (!state.lem && lc.size) h += `<details class="fl" open><summary>Леммы (${lc.size}) — нажмите для полной информации</summary><div class="chips">` +
    [...lc].sort((a, b) => b[1] - a[1]).map(([l, n]) => `<button class="chip" data-lem="${esc(l)}"><span class="ar">${ar(l)}</span><small>${n}</small></button>`).join('') + `</div></details>`;
  return h;
}
function renderLemma() {
  const all = byLemma.get(state.lem), es = currentEntries(null);
  const rr = all.find(r => r.root), rt = rr ? rr.root : '';
  const tg = new Map(), sur = new Set(), ay = new Set();
  for (const r of all) { tg.set(r.tag, (tg.get(r.tag) || 0) + 1); sur.add(r.s); ay.add(r.s * 1000 + r.a); }
  const first = all[0];
  const groups = new Map();
  for (const r of es) (groups.get(r.tag) || groups.set(r.tag, []).get(r.tag)).push(r);
  const tags = [...groups.keys()].sort((x, y) => { const i = TORD.indexOf(x), j = TORD.indexOf(y); return (i < 0 ? 99 : i) - (j < 0 ? 99 : j) || x.localeCompare(y); });
  let shown = 0, html = '';
  for (const t of tags) {
    if (shown >= state.limit) break;
    const rows = groups.get(t).slice(0, state.limit - shown); shown += rows.length;
    html += `<h3>${TN[t] || t} <small>(${t}) — ${groups.get(t).length}</small></h3><div class="tw"><table><thead><tr><th>Location</th><th>Form</th><th>Перевод</th><th>Lemma / признаки</th><th>Аят</th></tr></thead><tbody>` + rows.map(rowHTML).join('') + `</tbody></table></div>`;
  }
  $('#view').innerHTML = `<div class="sum"><span class="ar" style="font-size:1.8rem;color:var(--acc)">${ar(state.lem)}</span> — ${all.length} раз<br>
    Лемма встречается ${all.length} раз в ${ay.size} аятах ${sur.size} сур, форм: ${new Set(all.map(r => r.form)).size}.<br>${rt && RM[rt] ? `Значение корня: <b>${esc(RM[rt])}</b><br>` : ''}
    Часть речи: ${[...tg].map(([t, n]) => `${esc(TN[t] || t)} (${n})`).join(', ')}.<br>
    ${rt ? `Корень: <a class="ar lk" data-root="${esc(rt)}" style="font-size:1.3rem" title="Все формы корня">${rootAr(rt)}</a> <button data-root="${esc(rt)}">Все формы корня</button><br>` : 'Корня нет (служебное слово).<br>'}
    Первое вхождение: <button class="loc" data-m="${first.i}" title="Показать в мусхафе">${loc(first)}</button>
    ${state.form ? `<br>Фильтр по форме: <b class="ar">${ar(state.form)}</b> <button data-c="clearform">✕ все формы леммы</button>` : ''}</div>` + chipsHTML(all) + html +
    (shown < es.length ? `<p><button data-c="more">Показать ещё ${Math.min(100, es.length - shown)} (осталось ${es.length - shown})</button></p>` : '');
  $('#count').textContent = `Показано ${fmt(shown)} из ${fmt(es.length)} вхождений`;
}
function showLemma(lem) {
  state.dm = 'roots';
  if (curTab !== 'dict') setTab('dict', true);
  const rr = (byLemma.get(lem) || []).find(r => r.root);
  state.lem = lem; state.form = ''; state.limit = 100; state.root = rr ? rr.root : null; if (rr) state.letter = rr.root[0];
  render(); window.scrollTo(0, 0);
}
function showRoot(root, form = '') { state.dm = 'roots'; if (curTab !== 'dict') setTab('dict', true); state.lem = ''; state.root = root; state.form = form; state.limit = 100; if (root) state.letter = root[0]; render(); window.scrollTo(0, 0); }

// ---------- Частотный словарь корней и «Словарь к сурам» (Qvocab) ----------
function renderFreq() {
  const list = [...rootList].sort((a, b) => b.n - a.n), shown = list.slice(0, state.limit);
  $('#view').innerHTML = `<p>Частотный словарь: <b>${fmt(list.length)}</b> корней по числу употреблений, значения из Qvocab.</p><div class="tw"><table><thead><tr><th>№</th><th>Корень</th><th>Значение</th><th>Раз</th></tr></thead><tbody>` +
    shown.map((o, i) => `<tr><td>${i + 1}</td><td><a class="ar lk" data-root="${esc(o.root)}" style="font-size:1.3rem">${rootAr(o.root)}</a></td><td>${esc(o.mean) || '—'}</td><td>${o.n}</td></tr>`).join('') + `</tbody></table></div>` +
    (shown.length < list.length ? `<p><button data-c="more">Показать ещё 100 (осталось ${list.length - shown.length})</button></p>` : '');
  $('#count').textContent = `Показано ${fmt(shown.length)} из ${fmt(list.length)} корней`;
}
function renderSura() {
  const s = state.vs, n = SN[s - 1].n, rows = [], seenR = new Set();
  for (let a = 1; a <= n; a++) {
    for (const r of aIdx.get(s * 1000 + a) || []) {
      if (!r.root || seenR.has(r.root) || !qwOf(r)) continue;
      seenR.add(r.root);
      if (state.thr && byRoot.get(r.root).n > state.thr) continue;
      rows.push(r);
    }
  }
  const shown = rows.slice(0, state.limit);
  const opt = (v, t, cur) => `<option value="${v}"${v === cur ? ' selected' : ''}>${t}</option>`;
  $('#view').innerHTML = `<div class="bar"><select id="vsel" aria-label="Сура">${SN.map((x, i) => opt(i + 1, `${i + 1}. ${esc(x.ru)} — ${x.ar}`, s)).join('')}</select><select id="vthr" aria-label="Порог частоты">${[[15, 'корни до 15 раз'], [50, 'корни до 50 раз'], [0, 'все корни']].map(([v, t]) => opt(v, t, state.thr)).join('')}</select></div>
    <p>Первое вхождение каждого корня в суре: <b>${fmt(rows.length)}</b></p><div class="tw"><table><thead><tr><th>Location</th><th>Слово</th><th>Корень</th><th>Перевод</th><th>Раз</th></tr></thead><tbody>` +
    shown.map(r => `<tr><td><button class="loc" data-m="${r.i}" title="Показать в мусхафе">${loc(r)}</button></td><td><span class="ar" style="font-size:1.3rem">${ayahWords(r.s, r.a).find(x => x.w === r.w).t}</span> <button class="info" data-i="${r.i}" title="Разбор слова" aria-label="Разбор слова">ⓘ</button></td><td><a class="ar lk" data-root="${esc(r.root)}">${rootAr(r.root)}</a></td><td>${esc(qwOf(r)[0])}</td><td>${byRoot.get(r.root).n}</td></tr>`).join('') + `</tbody></table></div>` +
    (shown.length < rows.length ? `<p><button data-c="more">Показать ещё 100 (осталось ${rows.length - shown.length})</button></p>` : '');
  $('#count').textContent = `Показано ${fmt(shown.length)} из ${fmt(rows.length)} слов`;
}

// ---------- modal ----------
function featTok(t) {
  const k = t.indexOf(':');
  if (k < 0) {
    if (/\+$/.test(t)) return ['Prefix', ar(t.slice(0, -1)), 1];
    return [t, /^[123][MF]?[SDP]$/.test(t) ? 'Person / gender / number' : /^\([IVX]+\)$/.test(t) ? 'Verb form ' + t.slice(1, -1) : FD[t] || '', 0];
  }
  const key = t.slice(0, k), v = t.slice(k + 1);
  if (key === 'POS') return ['POS', TN[v] || v, 0];
  if (key === 'SP') return ['SP', ar(v), 1];
  if (/\+$/.test(v) || key[0] === '+') return [key[0] === '+' ? 'Suffix' : 'Prefix', ar(key.replace('+', '')), 1];
  return [key, FD[v] || v, 0];
}
function openRec(r) {
  const segs = (aIdx.get(r.s * 1000 + r.a) || []).filter(x => x.w === r.w);
  const rows = r.feat.split('|').filter(t => !/^(ROOT|LEM):/.test(t)).map(featTok);
  const A = t => `<span class="ar">${t}</span>`;
  $('#dlg').innerHTML = `<h2>${loc(r)} <small style="color:var(--dim);font-weight:400">${TN[r.tag] || r.tag}</small></h2>
    <div class="big ar">${ar(segs.map(x => x.form).join(''))}</div>
    <p>Сегмент ${r.g}: <span class="ar" style="font-size:1.3rem">${ar(r.form)}</span></p>
    <table><tr><td>TAG</td><td>${esc(r.tag)} (${TN[r.tag] || '—'})</td></tr>
    <tr><td>Корень</td><td>${r.root ? `<a class="ar lk" data-root="${esc(r.root)}" title="Все формы корня">${rootAr(r.root)}</a> <small style="color:var(--dim)">все формы корня →</small>` : '—'}</td></tr>
    <tr><td>Лемма</td><td>${r.lem ? `<a class="ar lk" data-lem="${esc(r.lem)}" title="Всё о лемме">${ar(r.lem)}</a> <small style="color:var(--dim)">полная информация →</small>` : '—'}</td></tr>
    ${(() => { const q = qwOf(r); return (q ? `<tr><td>Перевод слова</td><td>${esc(q[0])}</td></tr>${gramRu(q[1]) ? `<tr><td>Грамматика</td><td>${esc(gramRu(q[1]))}</td></tr>` : ''}` : '') + (r.root && RM[r.root] ? `<tr><td>Значение корня</td><td>${esc(RM[r.root])}</td></tr>` : ''); })()}
    ${rows.map(x => `<tr><td>${esc(x[0])}</td><td>${x[2] ? A(x[1]) : esc(x[1])}</td></tr>`).join('')}</table>
    <h3>Все сегменты слова</h3>
    <table>${segs.map(x => `<tr${x === r ? ' style="color:var(--acc)"' : ''}><td>${loc(x)}:${x.g}</td><td>${A(ar(x.form))}</td><td>${esc(x.tag)}</td><td>${x.root ? A(rootAr(x.root)) : '—'}</td></tr>`).join('')}</table>
    <div class="bar">${r.root ? `<button data-c="sameform" data-i="${r.i}">Все вхождения этой формы</button>` : ''}<button data-c="tomushaf" data-i="${r.i}">Показать в мусхафе</button><button data-c="close" style="margin-left:auto">Закрыть</button></div>`;
  $('#dlg').showModal();
}

// ---------- events ----------
document.addEventListener('click', e => {
  const t = e.target.closest('[data-l],[data-root],[data-lem],[data-form],[data-c],[data-i],[data-dm],[data-m],[data-tr],.w');
  if (e.target === $('#dlg')) return $('#dlg').close();
  if (!t) return;
  if (t.dataset.dm) { state.dm = t.dataset.dm; state.root = null; state.lem = ''; state.limit = 100; return render(); }
  if (t.dataset.tr) { trPrefs[t.dataset.tr] = !trPrefs[t.dataset.tr]; try { localStorage.setItem('qd-tr', JSON.stringify(trPrefs)); } catch (e) {} return applyTrPrefs(); }
  if (t.dataset.m !== undefined) { const r = recs[+t.dataset.m]; return mushafOpen(r.s, r.a, r.w); }
  if (t.dataset.l !== undefined) { state.letter = t.dataset.l; state.root = null; state.lem = ''; state.q = ''; $('#q').value = ''; return render(); }
  if (t.dataset.root) { $('#dlg').close(); return showRoot(t.dataset.root); }
  if (t.dataset.lem) { $('#dlg').close(); return showLemma(t.dataset.lem); }
  if (t.dataset.form !== undefined) { state.form = state.form === t.dataset.form ? '' : t.dataset.form; state.limit = 100; return render(); }
  const c = t.dataset.c;
  if (c === 'all') { state.letter = ''; state.root = null; state.lem = ''; state.q = ''; $('#q').value = ''; return render(); }
  if (c === 'letter') { state.root = null; state.lem = ''; return render(); }
  if (c === 'more') { const y = window.scrollY; state.limit += 100; render(); return window.scrollTo(0, y); }
  if (c === 'clearform' || c === 'allforms') { state.form = ''; state.limit = 100; return render(); }
  if (c === 'close') return $('#dlg').close();
  if (c === 'tomushaf') { const r = recs[+t.dataset.i]; $('#dlg').close(); return mushafOpen(r.s, r.a, r.w); }
  if (c === 'sameform') { const r = recs[+t.dataset.i]; $('#dlg').close(); return showRoot(r.root, r.form); }
  if (t.classList.contains('w')) {
    if (t.closest('#mview')) { mst.sel = {id: idOf(+t.dataset.s, +t.dataset.a), w: +t.dataset.w}; applySel(true); }
    const segs = (aIdx.get(t.dataset.s * 1000 + +t.dataset.a) || []).filter(x => x.w === +t.dataset.w);
    return openRec(segs.find(x => x.root) || segs.find(x => x.feat.startsWith('STEM')) || segs[0]);
  }
  if (t.dataset.i !== undefined) openRec(recs[+t.dataset.i]);
});
document.addEventListener('change', e => {
  if (e.target.id === 'vsel') { state.vs = +e.target.value; state.limit = 100; render(); }
  if (e.target.id === 'vthr') { state.thr = +e.target.value; state.limit = 100; render(); }
});
let timer;
$('#q').addEventListener('input', e => {
  clearTimeout(timer);
  timer = setTimeout(() => { state.q = e.target.value; state.root = null; state.lem = ''; render(); }, 120);
});
$('#csv').addEventListener('click', async () => {
  const o = byRoot.get(state.root); if (!o) return;
  const q = v => '"' + String(v).replace(/"/g, '""') + '"';
  const rows = [['location', 'form', 'ru', 'tag', 'lemma', 'root', 'root_meaning', 'features', 'ayah', 'ayah_ru', 'ayah_uz'].map(q).join(',')];
  for (const r of currentEntries(o)) rows.push([loc(r), ar(r.form), (qwOf(r) || [''])[0], r.tag, ar(r.lem), rootAr(r.root), o.mean, featSum(r), ayahWords(r.s, r.a).map(x => x.t).join(' '), trPlain(r.s, r.a, 'ru'), trPlain(r.s, r.a, 'uz')].map(q).join(','));
  const csv = '\ufeff' + rows.join('\r\n'), fname = `root-${rootAr(o.root).replace(/\s/g, '')}.csv`;
  // в опубликованной странице сохранение идёт через capability downloads; локально — обычная ссылка
  const dl = window.claude && window.claude.use ? await window.claude.use('downloads') : null;
  if (dl) {
    try { await dl.save({filename: fname, data: csv}); }
    catch (e) { if (!e || e.code !== 'declined') $('#status').textContent = 'Не удалось сохранить CSV.'; }
    return;
  }
  const url = URL.createObjectURL(new Blob([csv], {type:'text/csv;charset=utf-8'}));
  const a = document.createElement('a'); a.href = url; a.download = fname; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
// ---------- theme ----------
function setTheme(t, save) {
  document.documentElement.dataset.theme = t;
  const b = $('#theme');
  b.textContent = t === 'dark' ? '🌙' : '☀️';
  b.setAttribute('aria-label', t === 'dark' ? 'Тёмная тема. Переключить на светлую' : 'Светлая тема. Переключить на тёмную');
  if (save) try { localStorage.setItem('qd-theme', t); } catch (e) {}
}
$('#theme').addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark', true));
setTheme(document.documentElement.dataset.theme, false);

// ---------- Мусхаф (Мединский мусхаф, Хафс, 604 страницы) ----------
const MM = JSON.parse(DATA['mushaf-meta']);   // S: суры; P/J/Q/R/X: начала страниц, джузов, четвертей хизба, рукуъ; саджды (абсолютные номера аятов)
let MK = null;  // m: знаки остановки/сакта по словам; y: слова с малой верхней йа (ۧ) — для режимов «Сура» и «Джуз»
let MP = null;  // p[i] = [номер аята первого слова, слов от начала аята, строки]; a = привязка слов страницы к словам корпуса
const SN = MM.S.map(r => ({ar: r[0], ru: r[1], mean: r[2], n: r[3], mec: r[4], ord: r[5], first: r[6], rk: r[7]}));
const NA = 6236;
const PG = new Map(MM.P.map((id, i) => [id, i + 1]));
const JZ = new Map(MM.J.map((id, i) => [id, i + 1]));
const QR = new Map(MM.Q.map((id, i) => [id, i]));
const RK_ = new Set(MM.R), SJ = new Set(MM.X);
const sOf = id => { let lo = 0, hi = 113; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (SN[m].first <= id) lo = m; else hi = m - 1; } return lo + 1; };
const idOf = (s, a) => SN[s - 1].first + a - 1;
const aOf = id => id - SN[sOf(id) - 1].first + 1;
const upto = (arr, id) => { let lo = 0, hi = arr.length; while (lo < hi) { const m = (lo + hi) >> 1; if (arr[m] <= id) lo = m + 1; else hi = m; } return lo; };
const ind = n => String(n).replace(/\d/g, d => String.fromCharCode(0x660 + +d));
const plr = (n, a, b, c) => { const m = n % 100, d = n % 10; return m > 10 && m < 15 ? c : d === 1 ? a : d > 1 && d < 5 ? b : c; };
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const LSX = {get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }};

let curTab = 'dict';
const mst = {mode: 'page', surah: 1, page: 1, juz: 1, anchor: 1, lines: false, fs: matchMedia('(max-width:600px)').matches ? 1.7 : 2, tgt: null, bm: 0, ready: false};
(function loadPrefs() {
  try {
    const p = JSON.parse(LSX.get('qd-m2') || 'null') || {};
    if (p.fs >= 1.1 && p.fs <= 4) mst.fs = p.fs;
    mst.lines = !!p.lines;
    if (['surah', 'page', 'juz'].includes(p.mode)) mst.mode = p.mode;
    if (p.id >= 1 && p.id <= NA) setAnchor(p.id);
    if (p.bm >= 1 && p.bm <= NA) mst.bm = p.bm;
  } catch (e) {}
})();
function setAnchor(id) { mst.anchor = id; mst.surah = sOf(id); mst.page = upto(MM.P, id); mst.juz = upto(MM.J, id); }
function savePrefs() { LSX.set('qd-m2', JSON.stringify({fs: mst.fs, lines: mst.lines, mode: mst.mode, id: mst.anchor, bm: mst.bm})); }

function unitRange() {
  if (mst.mode === 'surah') { const s = SN[mst.surah - 1]; return [s.first, s.first + s.n - 1]; }
  if (mst.mode === 'page') return [MM.P[mst.page - 1], (MM.P[mst.page] || NA + 1) - 1];
  return [MM.J[mst.juz - 1], (MM.J[mst.juz] || NA + 1) - 1];
}
// слова аята (режимы «Сура»/«Джуз»): текст корпуса + знаки остановки, сакта, малая верхняя йа
function mWords(s, a) {
  const key = s + ':' + a, ms = MK.m[key], ys = MK.y[key];
  return ayahWords(s, a).map(x => {
    let t = x.t;
    if (ys && ys.includes(x.w)) t = t.replace('ۦ', 'ۧ');
    if (ms) for (const e of ms) if (e[0] === x.w) t += e[1];
    return {w: x.w, t};
  });
}
let bismText = '';
const getBism = () => bismText || (bismText = mWords(1, 1).map(x => x.t).join(' '));

// баннер суры: зелёная панель с решёткой, розетками и белым картушем (в тёмной теме — контурный)
const ROS = (cls) => `<svg class="bn-ros ${cls}" viewBox="-32 -32 64 64" aria-hidden="true"><g fill="var(--bn-pet)" stroke="var(--bn-ed)" stroke-width="1.3">${
  [0, 1, 2, 3, 4, 5, 6, 7].map(k => `<ellipse cx="0" cy="-19" rx="7.4" ry="12" transform="rotate(${k * 45})"/>`).join('')}</g><circle r="13.5" fill="var(--bn-ct)" stroke="var(--bn-ed)" stroke-width="1.6"/><circle r="5.5" fill="var(--bn-bg)" stroke="var(--bn-ed)" stroke-width="1"/></svg>`;
function banner(s) {
  return `<div class="bnr-wrap" id="s${s}"><div class="bnr" role="img" aria-label="Сура ${s}: ${esc(SN[s - 1].ru)}"><svg class="bn-bg" viewBox="0 0 600 66" preserveAspectRatio="none" aria-hidden="true"><defs><pattern id="bnlt" width="22" height="22" patternUnits="userSpaceOnUse"><path d="M11 0L22 11L11 22L0 11Z" fill="none" stroke="var(--bn-ln)" stroke-width="1.1"/></pattern></defs>
    <rect x="1.5" y="1.5" width="597" height="63" fill="var(--bn-bg)" stroke="var(--bn-ed)" stroke-width="3"/><rect x="1.5" y="1.5" width="597" height="63" fill="url(#bnlt)"/><rect x="7" y="7" width="586" height="52" fill="none" stroke="var(--bn-ed)" stroke-width="1.2"/></svg>
    ${ROS('l')}${ROS('r')}<div class="bn-ct" lang="ar">سورة ${SN[s - 1].ar}</div></div></div>`;
}
function surahHead(s) {
  const m = SN[s - 1];
  return banner(s) + `<div class="mcap">${esc(m.ru)} — ${esc(m.mean)} · ${m.mec ? 'мекканская' : 'мединская'} · ${m.n} ${plr(m.n, 'аят', 'аята', 'аятов')}</div>` +
    (s !== 1 && s !== 9 ? `<div class="bism" lang="ar">${getBism()}</div>` : '');
}
// ----- режимы «Сура» и «Джуз»: сплошной текст -----
function mushafHTML(a0, a1) {
  let out = '', buf = '';
  const lines = mst.lines, showPg = mst.mode !== 'page';
  const flush = () => { if (buf) { out += `<p class="mtext" lang="ar" dir="rtl">${buf}</p>`; buf = ''; } };
  for (let id = a0; id <= a1; id++) {
    const s = sOf(id), a = aOf(id);
    if (a === 1) { flush(); out += surahHead(s); }
    if (JZ.has(id)) { flush(); const j = JZ.get(id); out += `<div class="mjuz">Джуз ${j} · <span class="ar">الجزء ${ind(j)}</span></div>`; }
    let pre = '';
    if (showPg && PG.has(id)) pre += `<span class="mpg" dir="ltr">стр. ${PG.get(id)}</span>`;
    if (QR.has(id)) { const q = QR.get(id); pre += `<span class="mq${q % 4 === 0 ? ' h' : ''}" title="Хизб ${(q >> 2) + 1}, четверть ${(q & 3) + 1}">۞</span>`; }
    const ws = mWords(s, a).map(x => `<span class="w" data-s="${s}" data-a="${a}" data-w="${x.w}">${x.t}</span>`).join(' ');
    const end = markerHTML(id, ind(a)) + (SJ.has(id) ? '<span class="msj" title="Саджда тилява">۩</span>' : '') +
      (RK_.has(id + 1) || id === NA ? '<span class="mr" title="Конец рукуъ">ع</span>' : '');
    if (lines) out += `<div class="mayah" lang="ar" dir="rtl" data-id="${id}">${pre}${ws} ${end}</div>`;
    else buf += pre + ws + ' ' + end + ' ';
  }
  flush();
  return out;
}
function markerHTML(id, digits) {
  const s = sOf(id), a = aOf(id);
  return `<span class="mk${digits.length > 2 ? ' l3' : ''}${mst.bm === id ? ' bm' : ''}" data-id="${id}" role="button" tabindex="0" title="${s}:${a}" aria-label="Аят ${s}:${a}. Показать перевод">${digits}</span>`;
}
// ----- режим «Страница»: 15 строк Мединского мусхафа -----
const MKR = /^[﴾﴿][٠-٩]+[﴾﴿]$/;
const PAUSE = /^[ۖ-ۛ]+$/, SIGN = /^[ۖ-ۛ۞۩]+$/;
function tokensHTML(text, cur, seen) {
  let out = '';
  for (const tok of text.split(' ')) {
    if (MKR.test(tok)) { out += ' ' + markerHTML(cur.id, tok.replace(/[﴾﴿]/g, '')); cur.id++; cur.k = 0; continue; }
    if (SIGN.test(tok)) { out += (PAUSE.test(tok) ? '' : ' ') + `<span class="sg${PAUSE.test(tok) ? '' : ' q'}">${tok}</span>`; continue; }
    const id = cur.id, s = sOf(id), a = aOf(id), am = MP.a[id], w = am ? am[cur.k] : cur.k + 1;
    cur.k++; if (seen[seen.length - 1] !== s) seen.push(s);
    out += (out ? ' ' : '') + `<span class="w" data-s="${s}" data-a="${a}" data-w="${w}">${tok}</span>`;
  }
  return out;
}
function pageHTML(p) {
  const [id0, k0, lines] = MP.p[p - 1];
  const cur = {id: id0, k: k0}, seen = [];
  let rows = p <= 2 ? 8 : 15, body = '';
  for (const ln of lines) {
    const l = ln[0], kind = ln[1]; rows = Math.max(rows, l);
    if (kind === 0) { seen.push(ln[2]); body += `<div class="pl hd" style="grid-row:${l}">${banner(ln[2])}</div>`; }
    else if (kind === 1) body += `<div class="pl bs" style="grid-row:${l}"><span class="pli" lang="ar">${getBism()}</span></div>`;
    else body += `<div class="pl ${kind === 3 ? 'ct' : 'jt'}" style="grid-row:${l}" lang="ar"><span class="pli">${tokensHTML(ln[2], cur, seen)}</span></div>`;
  }
  const first = id0 || MM.P[p - 1], names = [...new Set(seen.length ? seen : [sOf(first)])].map(n => SN[n - 1].ru);
  return `<div class="mpage"><div class="mpc"><div class="mph"><span>Джуз ${upto(MM.J, first)}</span><span>${esc(names.join(' · '))}</span></div>` +
    `<div class="mgrid" style="--rows:${rows};--rowh:${p <= 2 ? 24 : 13}cqw">${body}</div><div class="mpn"><span>${ind(p)}</span></div></div></div>`;
}
// растягиваем каждую строку по ширине, как в печатном мусхафе
function fitPage() {
  const run = () => document.querySelectorAll('#mview .pl.jt .pli, #mview .pl.ct .pli, #mview .pl.bs .pli').forEach(el => {
    el.style.transform = 'none';
    const cw = el.parentElement.clientWidth, nw = el.offsetWidth;
    if (!nw || !cw) return;
    const justify = el.parentElement.classList.contains('jt');
    el.style.transform = `scaleX(${justify ? Math.min(1.7, cw / nw) : Math.min(1, cw / nw)})`;
  });
  if (document.fonts && document.fonts.load) document.fonts.load('24px HafsEmb', 'بسم الله').then(run, run); else run();
}
let fitT;
window.addEventListener('resize', () => { if (curTab === 'mushaf' && mst.mode === 'page') { clearTimeout(fitT); fitT = setTimeout(fitPage, 120); } });

function unitLabel(a0, a1) {
  const s0 = sOf(a0), s1 = sOf(a1), p0 = upto(MM.P, a0), p1 = upto(MM.P, a1), j0 = upto(MM.J, a0), j1 = upto(MM.J, a1);
  const R = (x, y) => x === y ? x : x + '–' + y;
  if (mst.mode === 'surah') return `Сура ${s0} «${SN[s0 - 1].ru}» · стр. ${R(p0, p1)} · джуз ${R(j0, j1)}`;
  if (mst.mode === 'page') return `Страница ${mst.page} из 604 · ${s0 === s1 ? 'сура ' + s0 + ' «' + SN[s0 - 1].ru + '»' : 'суры ' + s0 + '–' + s1} · джуз ${j0}`;
  return `Джуз ${j0} · суры ${R(s0, s1)} · стр. ${R(p0, p1)}`;
}
function syncToolbar() {
  document.querySelectorAll('[data-mm]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.mm === mst.mode)));
  $('#msurah').value = mst.surah; $('#mjuzsel').value = mst.juz; $('#mpage').value = mst.page;
  $('#msurah').hidden = mst.mode !== 'surah'; $('#mjuzsel').hidden = mst.mode !== 'juz'; $('#mpage').closest('label').hidden = mst.mode !== 'page';
  const max = mst.mode === 'surah' ? 114 : mst.mode === 'page' ? 604 : 30, cur = mst[mst.mode];
  $('#mprev').disabled = cur <= 1; $('#mnext').disabled = cur >= max;
  $('#mlines').checked = mst.lines; $('#mlines').closest('label').hidden = mst.mode === 'page';
  const bm = $('#mbm'); bm.disabled = !mst.bm; bm.textContent = mst.bm ? `Закладка ${sOf(mst.bm)}:${aOf(mst.bm)}` : 'Закладка';
}
function hashFor() {
  if (curTab === 'dict') return '#/dict';
  const t = mst.tgt && mst.tgt.id;
  return mst.mode === 'surah' ? `#/mushaf/${t ? sOf(t) + ':' + aOf(t) : mst.surah + ':1'}` : mst.mode === 'page' ? `#/mushaf/p/${mst.page}` : `#/mushaf/j/${mst.juz}`;
}
function renderMushaf(tries = 0) {
  syncToolbar();
  const box = $('#mview');
  if (!mst.ready) { box.innerHTML = '<p class="empty">Загрузка текста…</p>'; return; }
  const [a0, a1] = unitRange();
  box.style.setProperty('--mfs', mst.fs + 'rem');
  box.style.setProperty('--pgw', Math.round(mst.fs * 280) + 'px');
  box.classList.toggle('lines', mst.lines && mst.mode !== 'page');
  const t = mst.tgt;
  if (mst.mode === 'page') box.innerHTML = pageHTML(mst.page);
  else box.innerHTML = mushafHTML(a0, a1);
  if (t && t.w && mst.mode === 'page' && !box.querySelector(`.w[data-s="${sOf(t.id)}"][data-a="${aOf(t.id)}"][data-w="${t.w}"]`) && mst.page < 604 && tries < 3) {
    mst.page++; renderMushaf(tries + 1); return;     // слово аята, начатого на предыдущей странице, лежит дальше
  }
  $('#mpos').textContent = unitLabel(a0, a1);
  $('#count').textContent = mst.mode === 'page' ? `Страница ${mst.page} из 604` : `Аятов: ${fmt(a1 - a0 + 1)} · стр. ${upto(MM.P, a0)}${upto(MM.P, a1) !== upto(MM.P, a0) ? '–' + upto(MM.P, a1) : ''}`;
  if (mst.mode === 'page') fitPage();
  if (t) {
    const s = sOf(t.id), a = aOf(t.id);
    const ws = [...box.querySelectorAll(`.w[data-s="${s}"][data-a="${a}"]`)];
    const one = t.w && ws.find(x => +x.dataset.w === t.w);
    if (!t.quiet) { if (one) one.classList.add('hit'); else ws.forEach(x => x.classList.add('af')); }
    const el = one || ws[0];
    if (el && (mst.mode !== 'page' || !t.quiet)) setTimeout(() => el.scrollIntoView({block: 'center'}), mst.mode === 'page' ? 60 : 0);
    if (!t.quiet) setTimeout(() => ws.forEach(x => x.classList.remove('af')), 3500);
  }
  try { history.replaceState(null, '', hashFor()); } catch (e) {}
  savePrefs();
}
// ---------- Панель перевода аята в мусхафе (UZ основной, RU сворачиваемый) + фраза пословного перевода ----------
mst.sel = null;
const _renderMushaf = renderMushaf;
renderMushaf = function (t) { _renderMushaf(t); applySel(); };
function phraseOf(s, a, w) {
  const ws = ayahWords(s, a); if (!ws.length) return null;
  const k = i => (s * 1000 + a) * 1000 + i, last = ws[ws.length - 1].w;
  let st = 0; for (let i = w; i >= 1; i--) if (QW.has(k(i))) { st = i; break; }
  if (!st) return null;
  let en = last; for (let i = w + 1; i <= last; i++) if (QW.has(k(i))) { en = i - 1; break; }
  return {st, en, t: QW.get(k(st))[0]};
}
function applySel(reveal) {
  const box = $('#mview'), p = $('#mtr');
  box.querySelectorAll('.mk.sel,.w.ph,.w.pm').forEach(x => x.classList.remove('sel', 'ph', 'pm'));
  if (!mst.sel || !mst.ready) { p.hidden = true; return; }
  const {id, w} = mst.sel, s = sOf(id), a = aOf(id);
  const mk = box.querySelector(`.mk[data-id="${id}"]`); if (mk) mk.classList.add('sel');
  const ph = w ? phraseOf(s, a, w) : null;
  if (ph) for (let i = ph.st; i <= ph.en; i++) box.querySelectorAll(`.w[data-s="${s}"][data-a="${a}"][data-w="${i}"]`).forEach(x => x.classList.add('ph'));
  { // фраза, которая повторяется в других аятах (выбрана в блоке «Похожие места» или пришли по ссылке оттуда)
    const sl = mst.sel; let rg = sl.hl;
    if (!rg && sl.g != null) { const gg = similarOf(id)[sl.g]; if (gg) rg = [gg.from, gg.to]; }
    if (rg) { const ws = ayahWords(s, a); for (let i = rg[0]; i <= rg[1]; i++) if (ws[i]) box.querySelectorAll(`.w[data-s="${s}"][data-a="${a}"][data-w="${ws[i].w}"]`).forEach(x => x.classList.add('pm')); }
  }
  const uz = TR ? (TR.uz[s + ':' + a] || '') : '', ru = TR ? (TR.ru[s + ':' + a] || '') : '';
  const keep = _msLast === id ? p.scrollTop : 0; _msLast = id;
  p.hidden = false;
  p.innerHTML = `<div class="mtr-h"><b>${esc(SN[s - 1].ru)} ${s}:${a}</b><span class="grow"></span>
    <button type="button" data-mt="prev" aria-label="Предыдущий аят">‹</button><button type="button" data-mt="next" aria-label="Следующий аят">›</button>
    <button type="button" data-mt="bm"${mst.bm === id ? ' aria-pressed="true"' : ''}>${mst.bm === id ? '✓ Закладка' : 'Закладка'}</button>
    <button type="button" data-mt="fn" aria-pressed="${trPrefs.fn}" title="Сноски переводчика">Сноски</button>
    <button type="button" data-mt="x" aria-label="Закрыть">✕</button></div>` +
    (ph ? `<div class="mtr-ph"><span class="lbl">Фраза</span>${esc(ph.t)}</div>` : '') +
    (TR ? `<div class="mtr-uz">${trFmt(uz)}</div><details id="mtr-ru"${trPrefs.ruo ? ' open' : ''}><summary>Русский перевод</summary><div class="tr">${trFmt(ru)}</div></details>` : '<p class="empty">Загрузка переводов…</p>') + (TR ? msHTML(id) : '');
  p.scrollTop = keep;
  if (reveal) {                                    // не прятать выбранный аят под панелью
    const el = box.querySelector('.w.ph,.w.pm') || mk || box.querySelector(`.w[data-s="${s}"][data-a="${a}"]`);
    if (el) { const r = el.getBoundingClientRect(), lim = innerHeight - p.offsetHeight - 24; if (r.bottom > lim || r.top < 60) scrollBy({top: r.bottom - lim + (r.top < 60 ? r.top - 120 : 0) , behavior: 'smooth'}); }
  }
}
function mtrAct(act, el) {
  if (!mst.sel) return;
  const id = mst.sel.id;
  if (act === 'msh') { const g = +el.dataset.g; mst.sel.g = mst.sel.g === g ? null : g; mst.sel.hl = null; return applySel(true); }
  if (act === 'msx') { (mst.sel.x = mst.sel.x || new Set()).add(+el.dataset.g); return applySel(); }
  if (act === 'msa') { mst.sel.all = true; return applySel(); }
  if (act === 'msg') {                                   // перейти к похожему месту
    const nid = +el.dataset.id, s = sOf(nid), a = aOf(nid);
    mst.sel = {id: nid, w: 0, hl: [+el.dataset.f, +el.dataset.t]};
    if (!$(`#mview .w[data-s="${s}"][data-a="${a}"]`)) { setAnchor(nid); mst.tgt = {id: nid, w: 0, quiet: true}; setTab('mushaf', true); renderMushaf(); setTimeout(() => applySel(true), 450); return; }
    return applySel(true);
  }
  if (act === 'x') { mst.sel = null; return applySel(); }
  if (act === 'bm') { setBookmark(id); return applySel(); }
  if (act === 'fn') { trPrefs.fn = !trPrefs.fn; try { localStorage.setItem('qd-tr', JSON.stringify(trPrefs)); } catch (e) {} applyTrPrefs(); return applySel(); }
  const nid = clamp(id + (act === 'next' ? 1 : -1), 1, 6236), s = sOf(nid), a = aOf(nid);
  mst.sel = {id: nid, w: 0};
  const first = $(`#mview .w[data-s="${s}"][data-a="${a}"]`);
  if (!first) return mushafOpen(s, a);
  applySel(true);
}
// ---------- Похожие места (муташабихат): повторяющиеся фразы из ≥3 слов, считаем по корпусу ----------
// Принцип как у Tarteel QUL: «аят → фразы» и «фраза → диапазоны слов по аятам»; здесь строится сразу из слов корпуса.
let MS = null, _msLast = 0;
const msCache = new Map(), MS_MIN = 3, MS_SHOW = 6, MS_CHIPS = 12;
function buildMS() {
  if (MS) return MS;
  const sk = [], aid = [], start = new Int32Array(NA + 2), idx = new Map();
  for (let id = 1; id <= NA; id++) {
    start[id] = sk.length;
    const m = new Map();
    for (const r of aIdx.get(sOf(id) * 1000 + aOf(id)) || []) m.set(r.w, (m.get(r.w) || '') + r.form);
    for (const e of [...m].sort((x, y) => x[0] - y[0])) { sk.push(skel(e[1])); aid.push(id); }
  }
  start[NA + 1] = sk.length;
  for (let id = 1; id <= NA; id++) for (let i = start[id]; i + MS_MIN <= start[id + 1]; i++) {
    const k = sk[i] + ' ' + sk[i + 1] + ' ' + sk[i + 2], l = idx.get(k);
    l ? l.push(i) : idx.set(k, [i]);
  }
  return MS = {sk, aid, start, idx};
}
function similarOf(id) {
  let out = msCache.get(id); if (out) return out;
  const M = buildMS(), st = M.start[id], n = M.start[id + 1] - st, runs = new Map(), all = [];
  for (let i = 0; i + MS_MIN <= n; i++) {
    const l = M.idx.get(M.sk[st + i] + ' ' + M.sk[st + i + 1] + ' ' + M.sk[st + i + 2]);
    if (!l || l.length < 2) continue;
    for (const j of l) {
      const B = M.aid[j], jb = j - M.start[B], d = jb - i;
      if (B === id && d === 0) continue;
      const key = B * 4096 + d + 2048, r = runs.get(key);
      if (r && r.i1 === i - 1) r.i1 = i; else { const nr = {B, i0: i, i1: i, jb}; runs.set(key, nr); all.push(nr); }
    }
  }
  const g = new Map();
  for (const r of all) {
    const k = r.i0 + '-' + r.i1;
    const e = g.get(k) || g.set(k, {from: r.i0, to: r.i1 + MS_MIN - 1, occ: []}).get(k);
    e.occ.push({id: r.B, f: r.jb, t: r.jb + (r.i1 - r.i0) + MS_MIN - 1});
  }
  const ws = ayahWords(sOf(id), aOf(id));
  out = [...g.values()].map(e => {
    e.occ.sort((x, y) => x.id - y.id || x.f - y.f);
    e.ay = new Set(e.occ.map(o => o.id)).size;
    e.txt = ws.slice(e.from, e.to + 1).map(x => x.t).join(' ');
    return e;
  }).sort((x, y) => (y.to - y.from) - (x.to - x.from) || y.occ.length - x.occ.length || x.from - y.from);
  msCache.set(id, out);
  return out;
}
function msHTML(id) {
  const g = similarOf(id); if (!g.length) return '';
  const sl = mst.sel, n = new Set(g.flatMap(e => e.occ.map(o => o.id))).size, lim = sl.all ? g.length : MS_SHOW;
  const rows = g.slice(0, lim).map((e, gi) => {
    const seen = new Set(), chips = e.occ.filter(o => !seen.has(o.id) && seen.add(o.id)), full = sl.x && sl.x.has(gi);
    return `<div class="ms-g"><button type="button" class="ar ms-p" data-mt="msh" data-g="${gi}" aria-pressed="${sl.g === gi}" title="Подсветить фразу в этом аяте">${e.txt}</button><span class="ms-n">в ${e.ay} ${e.ay % 10 === 1 && e.ay % 100 !== 11 ? 'другом аяте' : 'других аятах'}</span>
      <div class="ms-c">${chips.slice(0, full ? chips.length : MS_CHIPS).map(o => `<button type="button" class="ms-a" data-mt="msg" data-id="${o.id}" data-f="${o.f}" data-t="${o.t}" title="${esc(SN[sOf(o.id) - 1].ru)}">${sOf(o.id)}:${aOf(o.id)}</button>`).join('')}${!full && chips.length > MS_CHIPS ? `<button type="button" class="ms-a ms-more" data-mt="msx" data-g="${gi}">ещё ${chips.length - MS_CHIPS}</button>` : ''}</div></div>`;
  }).join('');
  return `<details id="mtr-ms"${trPrefs.mso ? ' open' : ''}><summary>Похожие места · ${n} ${n % 10 === 1 && n % 100 !== 11 ? 'аят' : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 'аята' : 'аятов'}</summary>${rows}${g.length > lim ? `<button type="button" class="ms-a ms-more" data-mt="msa">ещё фраз: ${g.length - lim}</button>` : ''}</details>`;
}
function mushafStep(d) {
  const k = mst.mode, max = k === 'surah' ? 114 : k === 'page' ? 604 : 30;
  const v = clamp(mst[k] + d, 1, max);
  setAnchor(k === 'surah' ? SN[v - 1].first : k === 'page' ? MM.P[v - 1] : MM.J[v - 1]);
  if (k === 'page') mst.page = v;
  mst.tgt = null; renderMushaf(); window.scrollTo(0, 0);
}
function mushafSetMode(m) {
  if (m === mst.mode) return;
  const id = mst.tgt ? mst.tgt.id : unitRange()[0];
  setAnchor(id); mst.mode = m; mst.tgt = {id, w: 0, quiet: true};
  renderMushaf();
}
// открыть мусхаф на аяте (s:a), при необходимости подсветить слово w
function mushafOpen(s, a, w) {
  s = clamp(+s || 1, 1, 114); a = clamp(+a || 1, 1, SN[s - 1].n);
  const id = idOf(s, a);
  setAnchor(id); mst.tgt = {id, w: w || 0};
  setTab('mushaf', true); renderMushaf();
}
function mushafGoPage(p) { p = clamp(p, 1, 604); setAnchor(MM.P[p - 1]); mst.page = p; mst.mode = 'page'; mst.tgt = null; renderMushaf(); window.scrollTo(0, 0); }
function mushafGoJuz(j) { setAnchor(MM.J[clamp(j, 1, 30) - 1]); mst.mode = 'juz'; mst.tgt = null; renderMushaf(); window.scrollTo(0, 0); }
function setBookmark(id) {
  const old = $('#mview .mk.bm'); if (old) old.classList.remove('bm');
  mst.bm = id; const n = $(`#mview .mk[data-id="${id}"]`); if (n) n.classList.add('bm');
  syncToolbar(); savePrefs();
  $('#mmsg').textContent = `Закладка: сура ${sOf(id)}, аят ${aOf(id)}`;
}
function jumpTo(txt) {
  const m = /^\s*(\d{1,3})(?:\s*[:.\s]\s*(\d{1,3}))?\s*$/.exec(txt);
  if (!m) { $('#mmsg').textContent = 'Введите номер суры или «сура:аят», например 2:255.'; return; }
  const s = +m[1];
  if (s < 1 || s > 114) { $('#mmsg').textContent = 'Номер суры — от 1 до 114.'; return; }
  const a = m[2] ? +m[2] : 1;
  if (a < 1 || a > SN[s - 1].n) { $('#mmsg').textContent = `В суре ${s} аятов: ${SN[s - 1].n}.`; return; }
  $('#mmsg').textContent = '';
  mushafOpen(s, a);
}
function openTOC() {
  const d = $('#toc');
  d.innerHTML = `<h2>Оглавление</h2><h3>Джузы</h3><div class="jgrid">` +
    Array.from({length: 30}, (_, i) => `<button type="button" data-tj="${i + 1}">${i + 1}</button>`).join('') +
    `</div><h3>Суры</h3><div class="tgrid">` +
    SN.map((m, i) => `<button type="button" data-ts="${i + 1}"><b>${i + 1}</b><span class="t">${esc(m.ru)}<small>${esc(m.mean)} · ${m.n} · стр. ${upto(MM.P, m.first)}</small></span><span class="ar">${m.ar}</span></button>`).join('') +
    `</div><div class="bar"><button type="button" data-tc style="margin-left:auto">Закрыть</button></div>`;
  d.showModal();
}
function setTab(t, noRender) {
  curTab = t;
  $('#dictpane').hidden = t !== 'dict'; $('#mushafpane').hidden = t !== 'mushaf';
  document.body.classList.toggle('in-mushaf', t === 'mushaf');
  document.querySelectorAll('nav [data-tab]').forEach(a => { const on = a.dataset.tab === t; a.classList.toggle('cur', on); on ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'); });
  $('#csv').hidden = t !== 'dict';
  if (noRender) return;
  if (t === 'dict') { if (mst.ready) render(); try { history.replaceState(null, '', '#/dict'); } catch (e) {} }
  else renderMushaf();
}
function routeFromHash() {
  const h = (location.hash || '').replace(/^#\/?/, '').split('/');
  if (h[0] === 'dict') { setTab('dict', true); return; }
  if (h[0] !== 'mushaf') return;
  setTab('mushaf', true);
  let m;
  if (h[1] === 'p' && +h[2] >= 1) { const p = clamp(+h[2], 1, 604); setAnchor(MM.P[p - 1]); mst.page = p; mst.mode = 'page'; }
  else if (h[1] === 'j' && +h[2] >= 1) { setAnchor(MM.J[clamp(+h[2], 1, 30) - 1]); mst.mode = 'juz'; }
  else if ((m = /^(\d+):(\d+)$/.exec(h[1] || ''))) { const s = clamp(+m[1], 1, 114), a = clamp(+m[2], 1, SN[s - 1].n), id = idOf(s, a); setAnchor(id); mst.tgt = {id, w: 0, quiet: a === 1}; }
}
function onCorpusReady() { mst.ready = true; if (curTab === 'mushaf') renderMushaf(); }
function initMushafUI() {
  $('#msurah').innerHTML = SN.map((m, i) => `<option value="${i + 1}">${i + 1}. ${esc(m.ru)} — ${m.ar} (${m.n})</option>`).join('');
  $('#mjuzsel').innerHTML = Array.from({length: 30}, (_, i) => `<option value="${i + 1}">Джуз ${i + 1}</option>`).join('');
  $('#msurah').addEventListener('change', e => { setAnchor(SN[+e.target.value - 1].first); mst.tgt = null; renderMushaf(); window.scrollTo(0, 0); });
  $('#mjuzsel').addEventListener('change', e => mushafGoJuz(+e.target.value));
  $('#mpage').addEventListener('change', e => { const p = parseInt(e.target.value, 10); if (p >= 1 && p <= 604) mushafGoPage(p); else { $('#mmsg').textContent = 'Страницы — от 1 до 604.'; syncToolbar(); } });
  $('#mjump').addEventListener('keydown', e => { if (e.key === 'Enter') { jumpTo(e.target.value); e.target.select(); } });
  $('#mjump').addEventListener('change', e => { if (e.target.value.trim()) jumpTo(e.target.value); });
  $('#mprev').addEventListener('click', () => mushafStep(-1));
  $('#mnext').addEventListener('click', () => mushafStep(1));
  $('#mfsm').addEventListener('click', () => { mst.fs = clamp(Math.round((mst.fs - 0.15) * 100) / 100, 1.1, 4); renderMushafKeep(); });
  $('#mfsp').addEventListener('click', () => { mst.fs = clamp(Math.round((mst.fs + 0.15) * 100) / 100, 1.1, 4); renderMushafKeep(); });
  $('#mlines').addEventListener('change', e => { mst.lines = e.target.checked; renderMushafKeep(); });
  $('#mbm').addEventListener('click', () => { if (mst.bm) mushafOpen(sOf(mst.bm), aOf(mst.bm)); });
  $('#mtocbtn').addEventListener('click', openTOC);
  document.querySelectorAll('[data-mm]').forEach(b => b.addEventListener('click', () => mushafSetMode(b.dataset.mm)));
  document.querySelectorAll('nav [data-tab]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); setTab(a.dataset.tab); window.scrollTo(0, 0); }));
  $('#mview').addEventListener('click', e => { const n = e.target.closest('.mk'); if (n) { const id = +n.dataset.id; if (mst.sel && mst.sel.id === id && !mst.sel.w) mst.sel = null; else mst.sel = {id, w: 0}; applySel(true); } });
  $('#mview').addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('mk')) { e.preventDefault(); mst.sel = {id: +e.target.dataset.id, w: 0}; applySel(true); } });
  $('#mtr').addEventListener('click', e => { const b = e.target.closest('[data-mt]'); if (b) mtrAct(b.dataset.mt, b); });
  $('#mtr').addEventListener('toggle', e => { if (e.target.id === 'mtr-ru' || e.target.id === 'mtr-ms') { trPrefs[e.target.id === 'mtr-ru' ? 'ruo' : 'mso'] = e.target.open; try { localStorage.setItem('qd-tr', JSON.stringify(trPrefs)); } catch (x) {} } }, true);
  $('#toc').addEventListener('click', e => {
    const t = e.target.closest('[data-ts],[data-tj],[data-tc]');
    if (e.target === $('#toc') || (t && t.hasAttribute('data-tc'))) return $('#toc').close();
    if (!t) return;
    $('#toc').close();
    if (t.dataset.ts) { mushafOpen(+t.dataset.ts, 1); window.scrollTo(0, 0); }
    else mushafGoJuz(+t.dataset.tj);
  });
  document.addEventListener('keydown', e => {
    if (curTab !== 'mushaf' || e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey) return;
    if ($('#dlg').open || $('#toc').open) return;
    const tg = e.target.tagName; if (tg === 'INPUT' || tg === 'SELECT' || tg === 'TEXTAREA') return;
    if (e.key === 'ArrowLeft') { e.preventDefault(); mushafStep(1); }   // арабская книга: вперёд — влево
    else if (e.key === 'ArrowRight') { e.preventDefault(); mushafStep(-1); }
  });
  window.addEventListener('hashchange', () => { const h = location.hash; if (h === hashFor()) return; routeFromHash(); curTab === 'mushaf' ? renderMushaf() : (mst.ready && render()); });
}
function renderMushafKeep() {
  if (mst.mode !== 'page') { const f = firstVisibleAyah(); if (f) mst.tgt = {id: f, w: 0, quiet: true}; }
  else mst.tgt = null;
  renderMushaf();
}
function firstVisibleAyah() {
  const ws = document.querySelectorAll('#mview .w'); let best = 0;
  for (const w of ws) { if (w.getBoundingClientRect().bottom > 140) { best = idOf(+w.dataset.s, +w.dataset.a); break; } }
  return best;
}

initMushafUI(); routeFromHash(); setTab(curTab, true);

// ---------- start: data is embedded in the page ----------
startStages();
