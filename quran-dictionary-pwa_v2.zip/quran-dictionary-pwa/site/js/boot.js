(function () {
  // Этап 1: только то, что нужно для первого экрана. Корпус по сурам, переводы слов и Мусхаф app.js догружает в фоне.
  var FILES = {
  "mushaf-meta": "data/mushaf-meta.js",
  "qv-roots": "data/qv-roots.js",
  "qv-gram": "data/qv-gram.js",
  "roots-index": "data/roots-index.js"
};
  var ids = Object.keys(FILES), done = 0, bar = document.querySelector('#boot-b i'), txt = document.getElementById('boot-t');
  function loadScript(src) {
    return new Promise(function (ok, bad) {
      var s = document.createElement('script'); s.src = src; s.onload = ok;
      s.onerror = function () { bad(new Error(src)); }; document.head.appendChild(s);
    });
  }
  window.loadScript = loadScript;
  window.DATA = window.DATA || {};
  function step() { done++; bar.style.width = Math.round(done / ids.length * 100) + '%'; txt.textContent = 'Загрузка… ' + done + '/' + ids.length; }
  Promise.all(ids.map(function (id) { return loadScript(FILES[id]).then(step); }))
    .then(function () { return loadScript('js/app.js'); })
    .then(function () { document.getElementById('boot').remove(); })
    .catch(function (e) { txt.textContent = 'Не удалось загрузить файл ' + e.message + '. Проверьте, что папка site целиком на месте, и обновите страницу.'; });

  // офлайн-кэш: только по http(s); в APK (Capacitor) не нужен, файлы уже внутри приложения
  if ('serviceWorker' in navigator && !window.Capacitor && /^https?:$/.test(location.protocol)) {
    var had = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.register('sw.js').catch(function () {});
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (!had || document.getElementById('upd')) return;
      var b = document.createElement('div'); b.id = 'upd';
      b.innerHTML = '<span>Доступна новая версия</span><button type="button">Обновить</button>';
      b.querySelector('button').onclick = function () { location.reload(); };
      document.body.appendChild(b);
    });
  }
})();
