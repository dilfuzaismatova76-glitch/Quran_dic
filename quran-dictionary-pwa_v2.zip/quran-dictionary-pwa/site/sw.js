// Автоматически создан split_single_file.py: не править руками.
const VERSION = '02fce8acbc';
const CACHE = 'qd-' + VERSION;
const ASSETS = {
"css/app.css": "e3377c0b44",
"data/corpus/001.js": "f96dc6d7a4",
"data/corpus/002.js": "1d210534e0",
"data/corpus/003.js": "e60d17443a",
"data/corpus/004.js": "66792076d7",
"data/corpus/005.js": "68682186ad",
"data/corpus/006.js": "02589d091d",
"data/corpus/007.js": "b0080e3712",
"data/corpus/008.js": "1963fac483",
"data/corpus/009.js": "2e50927c08",
"data/corpus/010.js": "cccf450ecf",
"data/corpus/011.js": "01c4d9f2a6",
"data/corpus/012.js": "375b872b5c",
"data/corpus/013.js": "8579b2a457",
"data/corpus/014.js": "f14db21b06",
"data/corpus/015.js": "d72b241e71",
"data/corpus/016.js": "a275309950",
"data/corpus/017.js": "d0a73315e3",
"data/corpus/018.js": "719c6cd8de",
"data/corpus/019.js": "daaa805062",
"data/corpus/020.js": "ec1a9bd8cd",
"data/corpus/021.js": "8c6d79dfb8",
"data/corpus/022.js": "5a4cfd3bac",
"data/corpus/023.js": "bbd9b78b82",
"data/corpus/024.js": "96f0f27b11",
"data/corpus/025.js": "80cf11eacd",
"data/corpus/026.js": "74b24e7d39",
"data/corpus/027.js": "25d57862ac",
"data/corpus/028.js": "5175b77d6c",
"data/corpus/029.js": "8026a10f9a",
"data/corpus/030.js": "5ba4687614",
"data/corpus/031.js": "d182acdabb",
"data/corpus/032.js": "38bdf1828f",
"data/corpus/033.js": "ffba466562",
"data/corpus/034.js": "1e27410e9f",
"data/corpus/035.js": "b38d37dd4d",
"data/corpus/036.js": "f0345c18da",
"data/corpus/037.js": "312f785f24",
"data/corpus/038.js": "a756fe9e6d",
"data/corpus/039.js": "a5f346c36f",
"data/corpus/040.js": "06d04440f2",
"data/corpus/041.js": "dbd31d69c2",
"data/corpus/042.js": "00345dc83d",
"data/corpus/043.js": "399a3b69e6",
"data/corpus/044.js": "3e9d687b17",
"data/corpus/045.js": "e0e19a7288",
"data/corpus/046.js": "2684ed5c4e",
"data/corpus/047.js": "02d3d061fe",
"data/corpus/048.js": "49b3737bc5",
"data/corpus/049.js": "7dfb492a04",
"data/corpus/050.js": "c3b672f9c7",
"data/corpus/051.js": "52e00be35a",
"data/corpus/052.js": "a4fb554cb8",
"data/corpus/053.js": "51729fc99a",
"data/corpus/054.js": "e04648dbd6",
"data/corpus/055.js": "7bead8eb42",
"data/corpus/056.js": "f31bfb41de",
"data/corpus/057.js": "dae406b1fb",
"data/corpus/058.js": "f390ad89d2",
"data/corpus/059.js": "2a04d4925f",
"data/corpus/060.js": "4ff2b8c2ce",
"data/corpus/061.js": "c6fcec8423",
"data/corpus/062.js": "20f1ef562f",
"data/corpus/063.js": "6568293645",
"data/corpus/064.js": "10044935ed",
"data/corpus/065.js": "55e5a74f95",
"data/corpus/066.js": "97d8d2560c",
"data/corpus/067.js": "fb85082aba",
"data/corpus/068.js": "22e111fc0f",
"data/corpus/069.js": "6f6fb8b68c",
"data/corpus/070.js": "0b42be6b45",
"data/corpus/071.js": "71fa837c6c",
"data/corpus/072.js": "ae01ee05f5",
"data/corpus/073.js": "1f40e86c0c",
"data/corpus/074.js": "9259143b70",
"data/corpus/075.js": "d26f96a50c",
"data/corpus/076.js": "47645abc69",
"data/corpus/077.js": "126a716bd3",
"data/corpus/078.js": "43e21088b6",
"data/corpus/079.js": "ad7649d2ae",
"data/corpus/080.js": "96f02ac64d",
"data/corpus/081.js": "144448d714",
"data/corpus/082.js": "8cd3f32efb",
"data/corpus/083.js": "8636e7257a",
"data/corpus/084.js": "8132b0682b",
"data/corpus/085.js": "df1f77a804",
"data/corpus/086.js": "d31d835021",
"data/corpus/087.js": "c0adff4bb6",
"data/corpus/088.js": "b4552cbfe2",
"data/corpus/089.js": "fd930eb9f7",
"data/corpus/090.js": "0df5bec867",
"data/corpus/091.js": "81e84e1284",
"data/corpus/092.js": "a32179d3c3",
"data/corpus/093.js": "08fb952c19",
"data/corpus/094.js": "e6e33e84d6",
"data/corpus/095.js": "20be9d060e",
"data/corpus/096.js": "d842d0c7a4",
"data/corpus/097.js": "30fbc4c848",
"data/corpus/098.js": "31aa35708b",
"data/corpus/099.js": "ddaca148e6",
"data/corpus/100.js": "1a46f74dc4",
"data/corpus/101.js": "7d75301f3f",
"data/corpus/102.js": "3ad005b461",
"data/corpus/103.js": "48720ea2d2",
"data/corpus/104.js": "f425b1217c",
"data/corpus/105.js": "fd0cb061ad",
"data/corpus/106.js": "32a2895847",
"data/corpus/107.js": "7ff5fff934",
"data/corpus/108.js": "fd84e763c0",
"data/corpus/109.js": "874ec696eb",
"data/corpus/110.js": "7b2a6d59bb",
"data/corpus/111.js": "de418c0664",
"data/corpus/112.js": "f7037d7cf4",
"data/corpus/113.js": "fec427e6b8",
"data/corpus/114.js": "d1329b7065",
"data/mushaf-marks.js": "c71c8a8780",
"data/mushaf-meta.js": "1d17c7f1b8",
"data/mushaf-pages.js": "a5b87bd5a2",
"data/qv-gram.js": "35a2d2e1fb",
"data/qv-roots.js": "4d0c0071d0",
"data/qv-words.js": "1aa4142563",
"data/roots-index.js": "adf7e08500",
"data/tr.js": "4c32c4feed",
"fonts/83cc344579.woff2": "d4193220cd",
"icons/icon-192.png": "bd35ad5767",
"icons/icon-512.png": "4d5cd6c8b8",
"icons/maskable-512.png": "e9d65b47bf",
"index.html": "d492feebb1",
"js/app.js": "e0b180bbb4",
"js/boot.js": "93c260ef1c",
"manifest.webmanifest": "435b4e53c3"
};   // путь -> хеш содержимого
const MANIFEST = '__manifest__';

async function previous() {
  const names = (await caches.keys()).filter(k => k.startsWith('qd-') && k !== CACHE);
  for (const n of names) {
    const c = await caches.open(n), m = await c.match(MANIFEST);
    if (m) return {cache: c, manifest: await m.json()};
  }
  return null;
}
async function install() {
  const prev = await previous(), cache = await caches.open(CACHE), queue = Object.keys(ASSETS);
  await Promise.all(Array.from({length: 6}, async () => {
    let path;
    while ((path = queue.shift())) {
      if (prev && prev.manifest[path] === ASSETS[path]) {          // файл не менялся: берём из старого кэша
        const hit = await prev.cache.match(path);
        if (hit) { await cache.put(path, hit); continue; }
      }
      const res = await fetch(path, {cache: 'reload'});             // изменился или новый: качаем
      if (!res.ok) throw new Error(path + ' ' + res.status);
      await cache.put(path, res);
    }
  }));
  const idx = await cache.match('index.html');
  if (idx) await cache.put('./', idx.clone());
  await cache.put(MANIFEST, new Response(JSON.stringify(ASSETS)));
}
self.addEventListener('install', e => e.waitUntil(install().then(() => self.skipWaiting())));
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('qd-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET' || new URL(r.url).origin !== self.location.origin) return;
  e.respondWith(caches.match(r, {ignoreSearch: true}).then(hit => hit || fetch(r).then(res => {
    if (res.ok) { const cp = res.clone(); caches.open(CACHE).then(c => c.put(r, cp)); }
    return res;
  }).catch(() => caches.match('index.html'))));
});
