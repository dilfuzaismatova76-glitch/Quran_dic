#!/usr/bin/env python3
"""
Превращает однофайловую версию словаря (весь код и данные внутри одного HTML)
в статический сайт PWA: код, стили, шрифты и данные лежат отдельными файлами,
работает офлайн (service worker), готов к GitHub Pages и к упаковке в APK.

Использование:
    python tools/split_single_file.py путь/к/Quran_Dictionary.html site
Повторный запуск пересобирает папку site с нуля.
"""
import base64, hashlib, json, os, re, shutil, sys

DATA_FILES = {  # id блока данных в HTML -> файл на сайте
    'qv-words': 'data/qv-words.js',
    'qv-roots': 'data/qv-roots.js',
    'qv-gram': 'data/qv-gram.js',
    'mushaf-meta': 'data/mushaf-meta.js',
    'mushaf-marks': 'data/mushaf-marks.js',
    'mushaf-pages': 'data/mushaf-pages.js',
}
TR_ID, TR_FILE = 'tr-data', 'data/tr.js'   # переводы аятов: gzip в base64, грузятся отдельно и позже


def write(root, rel, data):
    path = os.path.join(root, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'wb' if isinstance(data, bytes) else 'w', **({} if isinstance(data, bytes) else {'encoding': 'utf-8'})) as f:
        f.write(data)


ROOT_COUNTS = {}


def write_corpus(root, text):
    # корпус по сурам: data/corpus/001.js ... 114.js (обновляется только изменившаяся сура)
    by = {}
    for ln in text.split('\n'):
        if ln.startswith('('):
            by.setdefault(int(ln[1:ln.index(':')]), []).append(ln)
            m = re.search(r'\|ROOT:([^|]+)', ln)
            if m:
                ROOT_COUNTS[m.group(1)] = ROOT_COUNTS.get(m.group(1), 0) + 1
    assert len(by) == 114, 'в корпусе не 114 сур'
    for sura, lines in by.items():
        write(root, 'data/corpus/%03d.js' % sura, js_data('c%d' % sura, '\n'.join(lines) + '\n'))


def js_data(bid, text):
    # данные лежат в .js-файлах: так они подключаются обычным <script> и работают даже при открытии index.html двойным кликом (file://)
    return '(window.DATA=window.DATA||{})[%s]=%s;\n' % (json.dumps(bid), json.dumps(text, ensure_ascii=False))


def make_icons(root):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        print('! Pillow не установлен: иконки не созданы (pip install pillow)'); return
    def draw(size, maskable):
        im = Image.new('RGBA', (size, size), (18, 22, 27, 255))
        d = ImageDraw.Draw(im); k = size / 512
        if not maskable:
            m = Image.new('L', (size, size), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, size - 1, size - 1], int(96 * k), fill=255)
            im.putalpha(m)
        s = 0.62 if maskable else 0.8
        cx = cy = size / 2; r = size * 0.3 * s / 0.8
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(108, 196, 176, 255))
        d.ellipse([cx - r * 0.55, cy - r * 1.05, cx + r * 1.15, cy + r * 0.65], fill=(18, 22, 27, 255))
        sx, sy, sr = cx + r * 0.62, cy - r * 0.05, r * 0.2
        d.polygon([(sx, sy - sr), (sx + sr * .3, sy - sr * .3), (sx + sr, sy - sr * .2), (sx + sr * .45, sy + sr * .2), (sx + sr * .6, sy + sr), (sx, sy + sr * .5), (sx - sr * .6, sy + sr), (sx - sr * .45, sy + sr * .2), (sx - sr, sy - sr * .2), (sx - sr * .3, sy - sr * .3)], fill=(227, 182, 74, 255))
        return im
    for name, size, mk in (('icon-192', 192, False), ('icon-512', 512, False), ('maskable-512', 512, True)):
        os.makedirs(os.path.join(root, 'icons'), exist_ok=True)
        draw(size, mk).save(os.path.join(root, 'icons', name + '.png'))


SW_TEMPLATE = r"""// Автоматически создан split_single_file.py: не править руками.
const VERSION = '__VERSION__';
const CACHE = 'qd-' + VERSION;
const ASSETS = __ASSETS__;   // путь -> хеш содержимого
const MANIFEST = '__manifest__';

async function previous() {
  const names = (await caches.keys()).filter(k => k.startsWith('qd-') && k !== CACHE);
  for (const n of names) {
    const c = await caches.open(n), m = await c.match(MANIFEST);
    if (m) return {cache: c, manifest: await m.json()};
  }
  return null;
}
async function install() {
  const prev = await previous(), cache = await caches.open(CACHE), queue = Object.keys(ASSETS);
  await Promise.all(Array.from({length: 6}, async () => {
    let path;
    while ((path = queue.shift())) {
      if (prev && prev.manifest[path] === ASSETS[path]) {          // файл не менялся: берём из старого кэша
        const hit = await prev.cache.match(path);
        if (hit) { await cache.put(path, hit); continue; }
      }
      const res = await fetch(path, {cache: 'reload'});             // изменился или новый: качаем
      if (!res.ok) throw new Error(path + ' ' + res.status);
      await cache.put(path, res);
    }
  }));
  const idx = await cache.match('index.html');
  if (idx) await cache.put('./', idx.clone());
  await cache.put(MANIFEST, new Response(JSON.stringify(ASSETS)));
}
self.addEventListener('install', e => e.waitUntil(install().then(() => self.skipWaiting())));
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('qd-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET' || new URL(r.url).origin !== self.location.origin) return;
  e.respondWith(caches.match(r, {ignoreSearch: true}).then(hit => hit || fetch(r).then(res => {
    if (res.ok) { const cp = res.clone(); caches.open(CACHE).then(c => c.put(r, cp)); }
    return res;
  }).catch(() => caches.match('index.html'))));
});
"""


GUARD = r"""
// Телефонные файловые менеджеры открывают index.html как content://..., и браузер не видит соседние папки (css, js, data).
(function () {
  if (/^(https?|file|capacitor|app|ionic):$/.test(location.protocol)) return;
  document.addEventListener('DOMContentLoaded', function () {
    var d = document.createElement('div');
    d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#12161b;color:#e6e2d6;padding:24px 20px;font:16px/1.5 system-ui,sans-serif;overflow:auto';
    d.innerHTML = '<h2 style="margin:0 0 12px;font-size:20px">Так страница не откроется</h2>'
      + '<p>Файловый менеджер передал браузеру только один файл <b>index.html</b>, а стили, скрипты и данные лежат рядом в папках, и браузер их не видит.</p>'
      + '<p><b>Как открыть:</b></p><ol style="padding-left:20px">'
      + '<li>По ссылке на сайт (GitHub Pages): откройте адрес в Chrome, меню → «Установить приложение». После этого работает и без интернета.</li>'
      + '<li>Или возьмите однофайловую версию <b>Quran_Dictionary_Mushaf_v5.html</b>: она открывается прямо из файлового менеджера.</li></ol>';
    document.body.appendChild(d);
  });
})();
"""

def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    src = open(sys.argv[1], encoding='utf-8').read()
    out = sys.argv[2]
    shutil.rmtree(out, ignore_errors=True); os.makedirs(out)

    body = src[src.index('<body>') + 6:]
    body = re.sub(r'</body>\s*</html>\s*$', '', body)
    css, main_js, theme, markup, last = [], None, '', '', 0
    for m in re.finditer(r'<(style|script)\b([^>]*)>(.*?)</\1>', body, re.S):
        markup += body[last:m.start()]; last = m.end()
        tag, attrs, content = m.groups()
        bid = re.search(r'id="([^"]+)"', attrs)
        bid = bid.group(1) if bid else None
        if tag == 'style':
            css.append(content)
        elif bid == 'corpus':
            write_corpus(out, content.lstrip('\n'))
        elif bid in DATA_FILES:
            write(out, DATA_FILES[bid], js_data(bid, content.lstrip('\n') if attrs.find('text/plain') >= 0 else content.strip()))
        elif bid == TR_ID:
            write(out, TR_FILE, 'window.TR_B64=%s;\n' % json.dumps(content.strip()))
        elif 'qd-theme' in content and len(content) < 1500:
            theme = content
        elif not attrs.strip():
            main_js = content
        else:
            print('! неизвестный блок', attrs[:60])
    markup += body[last:]
    assert main_js, 'не найден основной скрипт'
    tm = re.search(r'<title>[^<]*</title>', src)
    title = tm.group(0) if tm else '<title>Quran Dictionary</title>'
    markup = markup.replace(title, '', 1)

    # ---- шрифты из CSS в отдельные файлы
    css = '\n'.join(css)
    def font(m):
        data = base64.b64decode(m.group(2)); name = 'fonts/' + hashlib.md5(data).hexdigest()[:10] + '.' + m.group(1)
        write(out, name, data); return 'url(../%s)' % name
    css = re.sub(r'url\(data:font/(woff2|woff|ttf);base64,([A-Za-z0-9+/=]+)\)', font, css)
    css += '''
#boot{position:fixed;inset:0;display:flex;flex-direction:column;gap:12px;align-items:center;justify-content:center;background:var(--bg,#12161b);color:var(--ink,#e6e2d6);z-index:9999;font:15px system-ui,sans-serif}
#boot-b{width:min(280px,70vw);height:6px;background:var(--line,#2b343e);border-radius:6px;overflow:hidden}
#boot-b i{display:block;height:100%;width:0;background:var(--acc,#6cc4b0);transition:width .2s}
#loadbar{position:fixed;left:0;right:0;bottom:0;z-index:9990;background:var(--panel,#1a2027);border-top:1px solid var(--line,#2b343e);padding:6px 14px;font:13px system-ui,sans-serif;color:var(--dim,#93a0ab)}
#loadbar i{display:block;height:3px;margin-top:5px;width:0;background:var(--acc,#6cc4b0);transition:width .2s}
#upd{position:fixed;left:50%;bottom:16px;transform:translateX(-50%);background:var(--panel,#1a2027);color:var(--ink,#e6e2d6);border:1px solid var(--acc,#6cc4b0);border-radius:10px;padding:8px 14px;z-index:9998;display:flex;gap:12px;align-items:center;font:14px system-ui,sans-serif}
'''
    write(out, 'css/app.css', css)

    # ---- JS приложения: этап 1 (список корней) сразу, корпус по сурам и тяжёлые данные в фоне
    js = main_js
    for bid in DATA_FILES:
        js = js.replace("document.getElementById('%s').textContent" % bid, "DATA['%s']" % bid)

    def patch(old, new):
        nonlocal js
        assert js.count(old) == 1, 'не найден фрагмент: ' + old[:70]
        js = js.replace(old, new)

    patch("""for (const ln of DATA['qv-words'].split('\\n')) {
  if (!ln) continue; const p = ln.split('\\t'), c = p[0].split(':');
  QW.set((+c[0] * 1000 + +c[1]) * 1000 + +c[2], [p[1], +p[2]]);
}""", """function buildQW(text) {
  for (const ln of text.split('\\n')) {
    if (!ln) continue; const p = ln.split('\\t'), c = p[0].split(':');
    QW.set((+c[0] * 1000 + +c[1]) * 1000 + +c[2], [p[1], +p[2]]);
  }
}""")
    patch("const MK = JSON.parse(DATA['mushaf-marks']);", "let MK = null;")
    patch("const MP = JSON.parse(DATA['mushaf-pages']);", "let MP = null;")
    patch("buildLetters(); render(); onCorpusReady();\n}", "corpusReady = true; setLoadBar(1, 1); buildLetters(); render(); onCorpusReady();\n}")
    patch("function render() {\n  document.querySelectorAll('#dmode button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.dm === state.dm)));\n",
          "function render() {\n  document.querySelectorAll('#dmode button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.dm === state.dm)));\n  if (!corpusReady && (state.dm === 'sura' || state.root || state.lem)) return waitMsg();\n")
    patch("function buildLetters() {", r"""// ---------- Поэтапная загрузка: список корней сразу, корпус по сурам догружается в фоне ----------
let corpusReady = false;
function setLoadBar(done, total, text) {
  let b = document.getElementById('loadbar');
  if (done >= total) { if (b) b.remove(); return; }
  if (!b) { b = document.createElement('div'); b.id = 'loadbar'; b.innerHTML = '<span></span><i></i>'; document.body.appendChild(b); }
  b.firstChild.textContent = text + ' ' + done + '/' + total; b.lastChild.style.width = Math.round(done / total * 100) + '%';
}
function waitMsg() {
  $('#view').innerHTML = '<p class="empty">Корпус ещё загружается — страница откроется сама, как только данные будут готовы.</p>';
  $('#count').textContent = ''; $('#csv').disabled = true;
}
function earlyRoots() {
  const idx = JSON.parse(DATA['roots-index']); delete DATA['roots-index'];
  rootList = idx.map(([root, n]) => { const mean = RM[root] || ''; return {root, n, mean, sk: skel(root), hay: skel(root), ru: mean.toLowerCase(), forms: new Set(), lemmas: new Set(), recs: null}; });
  $('#q').disabled = false; buildLetters(); render();
}
async function loadRest() {
  const nums = Array.from({length: 114}, (_, i) => i + 1), total = nums.length + 2;
  let done = 0; const tick = t => setLoadBar(Math.min(++done, total - 1), total, t);
  setLoadBar(0, total, 'Загрузка корпуса');
  const queue = nums.slice();
  await Promise.all(Array.from({length: 6}, async () => {
    let s; while ((s = queue.shift())) { await window.loadScript('data/corpus/' + String(s).padStart(3, '0') + '.js'); tick('Загрузка корпуса'); }
  }));
  await window.loadScript('data/qv-words.js'); buildQW(DATA['qv-words']); delete DATA['qv-words']; tick('Загрузка переводов слов');
  await Promise.all([window.loadScript('data/mushaf-marks.js'), window.loadScript('data/mushaf-pages.js')]);
  MK = JSON.parse(DATA['mushaf-marks']); MP = JSON.parse(DATA['mushaf-pages']); tick('Загрузка Мусхафа');
  const text = nums.map(s => DATA['c' + s]).join('');
  window.DATA = null;
  parseText(text, 'embedded');
  applyTrPrefs();
  loadTr().catch(e => console.warn('Переводы аятов недоступны:', e));
}
function startStages() {
  earlyRoots();
  loadRest().catch(e => { const b = document.getElementById('loadbar'); if (b) b.firstChild.textContent = 'Не удалось загрузить данные (' + e.message + '). Проверьте соединение и обновите страницу.'; });
}

function buildLetters() {""")
    old = "const bin = Uint8Array.from(atob(document.getElementById('tr-data').textContent.trim()), c => c.charCodeAt(0));"
    patch(old, "await window.loadScript('%s');\n  const bin = Uint8Array.from(atob(window.TR_B64), c => c.charCodeAt(0)); window.TR_B64 = null;" % TR_FILE)
    patch("parseText(DATA['corpus'], 'embedded');\napplyTrPrefs();\nloadTr().catch(e => console.warn('Переводы аятов недоступны:', e));", "startStages();") if "DATA['corpus']" in js else patch("parseText(document.getElementById('corpus').textContent, 'embedded');\napplyTrPrefs();\nloadTr().catch(e => console.warn('Переводы аятов недоступны:', e));", "startStages();")
    assert "getElementById('corpus')" not in js and "getElementById('qv-" not in js and "getElementById('mushaf-" not in js
    write(out, 'js/app.js', js)

    # индекс корней (порядок и счётчики совпадают с тем, что строит приложение после разбора корпуса)
    ord_ = re.search(r'const ORD = "([^"]+)"', js).group(1)
    rk = {c: i for i, c in enumerate(ord_)}
    order = sorted(ROOT_COUNTS, key=lambda r: [rk.get(c, 99) for c in r])
    write(out, 'data/roots-index.js', js_data('roots-index', json.dumps([[r, ROOT_COUNTS[r]] for r in order], ensure_ascii=False, separators=(',', ':'))))

    boot = r"""(function () {
  // Этап 1: только то, что нужно для первого экрана. Корпус по сурам, переводы слов и Мусхаф app.js догружает в фоне.
  var FILES = %s;
  var ids = Object.keys(FILES), done = 0, bar = document.querySelector('#boot-b i'), txt = document.getElementById('boot-t');
  function loadScript(src) {
    return new Promise(function (ok, bad) {
      var s = document.createElement('script'); s.src = src; s.onload = ok;
      s.onerror = function () { bad(new Error(src)); }; document.head.appendChild(s);
    });
  }
  window.loadScript = loadScript;
  window.DATA = window.DATA || {};
  function step() { done++; bar.style.width = Math.round(done / ids.length * 100) + '%%'; txt.textContent = 'Загрузка… ' + done + '/' + ids.length; }
  Promise.all(ids.map(function (id) { return loadScript(FILES[id]).then(step); }))
    .then(function () { return loadScript('js/app.js'); })
    .then(function () { document.getElementById('boot').remove(); })
    .catch(function (e) { txt.textContent = 'Не удалось загрузить файл ' + e.message + '. Проверьте, что папка site целиком на месте, и обновите страницу.'; });

  // офлайн-кэш: только по http(s); в APK (Capacitor) не нужен, файлы уже внутри приложения
  if ('serviceWorker' in navigator && !window.Capacitor && /^https?:$/.test(location.protocol)) {
    var had = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.register('sw.js').catch(function () {});
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (!had || document.getElementById('upd')) return;
      var b = document.createElement('div'); b.id = 'upd';
      b.innerHTML = '<span>Доступна новая версия</span><button type="button">Обновить</button>';
      b.querySelector('button').onclick = function () { location.reload(); };
      document.body.appendChild(b);
    });
  }
})();
""" % json.dumps({k: DATA_FILES[k] for k in ('mushaf-meta', 'qv-roots', 'qv-gram')} | {'roots-index': 'data/roots-index.js'}, indent=2)
    write(out, 'js/boot.js', boot)

    write(out, 'manifest.webmanifest', json.dumps({
        'name': 'Quran Dictionary', 'short_name': "Qur'an Dict", 'start_url': './', 'scope': './',
        'display': 'standalone', 'background_color': '#12161b', 'theme_color': '#12161b', 'lang': 'ru',
        'icons': [
            {'src': 'icons/icon-192.png', 'sizes': '192x192', 'type': 'image/png'},
            {'src': 'icons/icon-512.png', 'sizes': '512x512', 'type': 'image/png'},
            {'src': 'icons/maskable-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'}]}, ensure_ascii=False, indent=2))
    make_icons(out)

    write(out, 'index.html', f"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#12161b">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" href="icons/icon-192.png">
<link rel="apple-touch-icon" href="icons/icon-192.png">
{title}
<script>{theme}</script>
<script>{GUARD}</script>
<link rel="stylesheet" href="css/app.css">
</head>
<body>
{markup}
<div id="boot" role="status"><div id="boot-t">Загрузка данных…</div><div id="boot-b"><i></i></div></div>
<script src="js/boot.js"></script>
</body>
</html>
""")

    # ---- service worker: версия по содержимому; обновление докачивает только изменившиеся файлы
    files = sorted(os.path.relpath(os.path.join(d, f), out).replace(os.sep, '/') for d, _, fs in os.walk(out) for f in fs)
    hashes = {f: hashlib.sha1(open(os.path.join(out, f), 'rb').read()).hexdigest()[:10] for f in files}
    version = hashlib.sha1(json.dumps(hashes, sort_keys=True).encode()).hexdigest()[:10]
    write(out, 'sw.js', SW_TEMPLATE.replace('__VERSION__', version).replace('__ASSETS__', json.dumps(hashes, indent=0, sort_keys=True)))
    files.append('sw.js')
    tot = sum(os.path.getsize(os.path.join(out, f)) for f in files)
    print('версия', version, '| файлов', len(files), '| всего %.1f МБ' % (tot / 1e6))
    for f in files:
        sz = os.path.getsize(os.path.join(out, f))
        if sz > 100_000: print('  %-26s %6.2f МБ' % (f, sz / 1e6))


if __name__ == '__main__':
    main()
